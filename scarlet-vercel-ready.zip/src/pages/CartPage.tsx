import { useState } from 'react'
import { Link } from 'react-router-dom'
import { ArrowRight, Gem, Minus, Plus, ShoppingBag, Trash2 } from 'lucide-react'
import { formatPKR } from '../config/store'
import { usePageTitle } from '../lib/hooks'
import { cartSubtotal, lineTotal, useCartStore } from '../store/cartStore'
import { useSettingsStore } from '../store/settingsStore'
import { useEditorStore } from '../store/editorStore'
import { MiniNecklaceFromCart } from '../components/builder/MiniNecklace'
import { EmptyState } from '../components/ui/EmptyState'
import { ConfirmDialog } from '../components/ui/ConfirmDialog'

export default function CartPage() {
  usePageTitle('Shopping Bag')
  const [confirmClear, setConfirmClear] = useState(false)
  const lines = useCartStore((state) => state.lines)
  const removeLine = useCartStore((state) => state.removeLine)
  const setQuantity = useCartStore((state) => state.setProductQuantity)
  const clear = useCartStore((state) => state.clear)
  const loadDesign = useEditorStore((state) => state.loadDesign)
  const settings = useSettingsStore((state) => state.settings)
  const subtotal = cartSubtotal(lines)
  const estimatedShipping = subtotal >= settings.free_shipping_threshold_pkr ? 0 : settings.standard_shipping_pkr
  const estimatedTax = Math.round(((subtotal + estimatedShipping) * settings.tax_rate_pct) / 100)

  if (lines.length === 0) return (
    <div className="mx-auto max-w-7xl px-5 py-12 sm:px-6 lg:px-8">
      <EmptyState icon={ShoppingBag} title="Your bag is beautifully empty" description="Start with a single charm, or make a complete necklace in the design studio." action="Design a necklace" to="/builder" />
    </div>
  )

  return (
    <>
      <section className="border-b border-line bg-petal/40">
        <div className="mx-auto max-w-7xl px-5 py-10 sm:px-6 lg:px-8"><p className="eyebrow">Your selection</p><h1 className="mt-2 font-display text-4xl sm:text-5xl">Shopping bag</h1></div>
      </section>
      <section className="mx-auto grid max-w-7xl gap-8 px-5 py-10 sm:px-6 lg:grid-cols-[1fr_380px] lg:px-8 lg:py-14">
        <div>
          <div className="mb-4 flex items-center justify-between"><p className="text-[10px] uppercase tracking-[0.15em] text-muted">{lines.length} {lines.length === 1 ? 'design or item' : 'designs & items'}</p><button onClick={() => setConfirmClear(true)} className="text-[10px] uppercase tracking-[0.13em] text-muted underline underline-offset-4 hover:text-burgundy">Clear bag</button></div>
          <ul className="divide-y divide-line border-y border-line">
            {lines.map((line) => (
              <li key={line.id} className="py-5 sm:py-6">
                <div className="grid grid-cols-[100px_1fr] gap-4 sm:grid-cols-[150px_1fr] sm:gap-6">
                  <div className="mini-necklace-wrap aspect-square overflow-hidden rounded-2xl border border-line">
                    {line.type === 'product' ? <img src={line.image} alt="" className="h-full w-full object-cover" /> : <MiniNecklaceFromCart line={line} className="h-full w-full" />}
                  </div>
                  <div className="flex min-w-0 flex-col justify-center">
                    <div className="flex items-start justify-between gap-3">
                      <div><p className="eyebrow">{line.type === 'necklace' ? 'Your custom design' : 'Individual charm'}</p><h2 className="mt-1 font-display text-xl font-semibold sm:text-2xl">{line.name}</h2></div>
                      <button onClick={() => removeLine(line.id)} className="grid h-8 w-8 shrink-0 place-items-center rounded-full text-muted hover:bg-blush hover:text-burgundy" aria-label={`Remove ${line.name}`}><Trash2 size={16} /></button>
                    </div>
                    {line.type === 'product' ? (
                      <div className="mt-4 flex flex-wrap items-center justify-between gap-3">
                        <div className="qty-pill"><button onClick={() => setQuantity(line.id, line.quantity - 1)} aria-label={`Decrease ${line.name} quantity`}><Minus size={11} /></button><span>{line.quantity}</span><button onClick={() => setQuantity(line.id, line.quantity + 1)} disabled={line.quantity >= 20} aria-label={`Increase ${line.name} quantity`}><Plus size={11} /></button></div>
                        <p className="font-display text-xl font-semibold text-burgundy">{formatPKR(lineTotal(line))}</p>
                      </div>
                    ) : (
                      <div className="mt-3">
                        <p className="text-xs text-muted">Gold-tone demo chain + {line.positions.length} {line.positions.length === 1 ? 'charm' : 'charms'}</p>
                        <div className="mt-2 flex flex-wrap gap-1.5">{line.charms.map((charm) => <span key={charm.productId} className="rounded-full bg-blush px-2.5 py-1 text-[9px] uppercase tracking-wide text-burgundy">{charm.qty}× {charm.name}</span>)}</div>
                        <div className="mt-4 flex flex-wrap items-center justify-between gap-3">
                          <Link to="/builder" onClick={() => loadDesign(line.positions)} className="inline-flex items-center gap-1.5 text-[10px] uppercase tracking-[0.14em] text-burgundy underline underline-offset-4"><Gem size={13} /> Edit this design</Link>
                          <p className="font-display text-xl font-semibold text-burgundy">{formatPKR(lineTotal(line))}</p>
                        </div>
                      </div>
                    )}
                  </div>
                </div>
              </li>
            ))}
          </ul>
          <Link to="/shop" className="mt-5 inline-flex items-center gap-2 text-[10px] uppercase tracking-[0.15em] text-burgundy hover:underline">← Continue shopping</Link>
        </div>

        <aside className="h-fit rounded-2xl border border-line bg-white p-5 shadow-card lg:sticky lg:top-28 sm:p-6" aria-labelledby="summary-title">
          <p className="eyebrow">Almost yours</p><h2 id="summary-title" className="mt-1 font-display text-3xl">Order summary</h2>
          <dl className="mt-6 space-y-3 text-sm">
            <div className="flex justify-between gap-4"><dt className="text-muted">Subtotal</dt><dd className="font-medium">{formatPKR(subtotal)}</dd></div>
            <div className="flex justify-between gap-4"><dt className="text-muted">Standard shipping estimate</dt><dd className="font-medium">{estimatedShipping === 0 ? 'Complimentary' : formatPKR(estimatedShipping)}</dd></div>
            <div className="flex justify-between gap-4"><dt className="text-muted">Configured tax ({settings.tax_rate_pct}%)</dt><dd className="font-medium">{formatPKR(estimatedTax)}</dd></div>
          </dl>
          <div className="mt-5 flex items-end justify-between border-t border-line pt-5"><span className="text-sm font-medium">Estimated total</span><span className="font-display text-3xl font-semibold text-burgundy">{formatPKR(subtotal + estimatedShipping + estimatedTax)}</span></div>
          <p className="mt-3 text-[10px] leading-relaxed text-muted">Final shipping and prices are verified by the server after your delivery method is selected. Express shipping may differ.</p>
          <Link to="/checkout" className="btn-primary mt-6 w-full">Proceed to checkout <ArrowRight size={15} /></Link>
          {settings.free_shipping_threshold_pkr > 0 && subtotal < settings.free_shipping_threshold_pkr && <p className="mt-3 text-center text-[10px] text-muted">Add {formatPKR(settings.free_shipping_threshold_pkr - subtotal)} more for configured standard free shipping.</p>}
        </aside>
      </section>
      <ConfirmDialog open={confirmClear} title="Clear your bag?" description="This removes every item and custom necklace from the shopping bag. Your current studio design remains available." confirmLabel="Clear bag" danger onCancel={() => setConfirmClear(false)} onConfirm={() => { clear(); setConfirmClear(false) }} />
    </>
  )
}
