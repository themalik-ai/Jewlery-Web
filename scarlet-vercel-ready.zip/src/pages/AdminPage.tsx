import { FormEvent, useCallback, useEffect, useState } from 'react'
import { Link } from 'react-router-dom'
import { BarChart3, Box, ChevronRight, Edit3, ImagePlus, LogOut, Menu, Package, Plus, Save, Settings, ShoppingBag, Users, X } from 'lucide-react'
import { api } from '../lib/api'
import type { AdminUser, Category, Order, Product, PublicSettings } from '../lib/types'
import { formatPKR } from '../config/store'
import { usePageTitle } from '../lib/hooks'
import { useUiStore } from '../store/uiStore'
import { Logo } from '../components/layout/Logo'
import { ToastViewport } from '../components/layout/ToastViewport'

type Tab = 'overview' | 'products' | 'orders' | 'settings'
type StatsData = { stats: { productCount: number; orderCount: number; revenuePkr: number; lowStock: Product[] }; recentOrders: Order[] }

const blankProduct = (category = ''): Partial<Product> => ({
  slug: '', name: '', description: '', category, image_url: '/logo-mark.svg', alt_text: '', price_pkr: 0,
  material: 'Demo specification — verify before listing', finish: 'Demo finish — verify before listing',
  stock_quantity: 0, is_active: true, is_featured: false, is_new: false,
})

function slugify(value: string) {
  return value.toLowerCase().trim().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '')
}

export default function AdminPage() {
  usePageTitle('Admin Dashboard')
  const addToast = useUiStore((state) => state.addToast)
  const [token, setToken] = useState(() => sessionStorage.getItem('scarlet-admin-token') || '')
  const [user, setUser] = useState<AdminUser | null>(null)
  const [checking, setChecking] = useState(Boolean(token))
  const [tab, setTab] = useState<Tab>('overview')
  const [mobileMenu, setMobileMenu] = useState(false)
  const [stats, setStats] = useState<StatsData | null>(null)
  const [products, setProducts] = useState<Product[]>([])
  const [categories, setCategories] = useState<Category[]>([])
  const [orders, setOrders] = useState<Order[]>([])
  const [settings, setSettings] = useState<PublicSettings | null>(null)
  const [editing, setEditing] = useState<Partial<Product> | null>(null)
  const [categoryDraft, setCategoryDraft] = useState({ original: null as string | null, slug: '', name: '', description: '' })

  const logout = useCallback(() => {
    sessionStorage.removeItem('scarlet-admin-token')
    setToken(''); setUser(null); setStats(null); setProducts([]); setOrders([]); setSettings(null)
  }, [])

  const loadAll = useCallback(async (authToken: string) => {
    const [statsData, productData, orderData, settingsData] = await Promise.all([
      api.admin.stats(authToken), api.admin.products(authToken), api.admin.orders(authToken), api.admin.settings(authToken),
    ])
    setStats(statsData); setProducts(productData.products); setCategories(productData.categories); setOrders(orderData.orders); setSettings(settingsData.settings)
  }, [])

  useEffect(() => {
    if (!token) { setChecking(false); return }
    let active = true
    api.admin.me(token).then(async ({ user }) => {
      if (!active) return
      setUser(user)
      try { await loadAll(token) } catch (error) { if (active) addToast(error instanceof Error ? error.message : 'Admin data failed to load.', 'error') }
      if (active) setChecking(false)
    }).catch(() => { if (active) { logout(); setChecking(false) } })
    return () => { active = false }
  }, [token, loadAll, logout, addToast])

  async function login(email: string, password: string) {
    const result = await api.admin.login(email, password)
    sessionStorage.setItem('scarlet-admin-token', result.token)
    setUser(result.user); setToken(result.token); setChecking(true)
  }

  if (checking) return <div className="grid min-h-screen place-items-center bg-cream"><div className="text-center"><Logo /><div className="mx-auto mt-6 h-7 w-7 animate-spin rounded-full border-2 border-rose border-t-burgundy" /><p className="mt-3 text-xs text-muted">Opening the atelier office…</p></div></div>
  if (!token || !user) return <AdminLogin onLogin={login} />

  const nav = [
    { id: 'overview' as Tab, label: 'Overview', icon: BarChart3 },
    { id: 'products' as Tab, label: 'Products', icon: Box },
    { id: 'orders' as Tab, label: 'Orders', icon: ShoppingBag },
    { id: 'settings' as Tab, label: 'Store settings', icon: Settings },
  ]

  async function saveProduct(product: Partial<Product>) {
    try {
      const result = await api.admin.saveProduct(token, product.id || null, product)
      setProducts((current) => product.id ? current.map((item) => item.id === product.id ? result.product : item) : [...current, result.product].sort((a, b) => a.name.localeCompare(b.name)))
      setEditing(null); addToast(product.id ? 'Product updated.' : 'Product created.')
      const nextStats = await api.admin.stats(token); setStats(nextStats)
    } catch (error) { addToast(error instanceof Error ? error.message : 'Product could not be saved.', 'error'); throw error }
  }

  async function saveCategory(event: FormEvent) {
    event.preventDefault()
    try {
      const result = await api.admin.saveCategory(token, categoryDraft.original, { slug: categoryDraft.slug, name: categoryDraft.name, description: categoryDraft.description })
      setCategories((current) => categoryDraft.original
        ? current.map((category) => category.slug === categoryDraft.original ? result.category : category)
        : [...current, result.category])
      if (categoryDraft.original && categoryDraft.original !== result.category.slug) {
        setProducts((current) => current.map((product) => product.category === categoryDraft.original ? { ...product, category: result.category.slug } : product))
      }
      setCategoryDraft({ original: null, slug: '', name: '', description: '' }); addToast('Category saved.')
    } catch (error) { addToast(error instanceof Error ? error.message : 'Category could not be saved.', 'error') }
  }

  async function updateOrder(id: number, patch: { status?: string; payment_status?: string }) {
    try {
      const { order } = await api.admin.updateOrder(token, id, patch)
      setOrders((current) => current.map((item) => item.id === id ? order : item))
      addToast('Order status updated.')
      setStats(await api.admin.stats(token))
    } catch (error) { addToast(error instanceof Error ? error.message : 'Status could not be updated.', 'error') }
  }

  async function saveSettings(event: FormEvent) {
    event.preventDefault()
    if (!settings) return
    try { const result = await api.admin.saveSettings(token, settings); setSettings(result.settings); addToast('Store settings saved.') }
    catch (error) { addToast(error instanceof Error ? error.message : 'Settings could not be saved.', 'error') }
  }

  return (
    <div className="min-h-screen bg-[#F8F4F0]">
      <header className="sticky top-0 z-40 flex h-16 items-center justify-between border-b border-line bg-white px-4 lg:hidden">
        <Logo compact /><button onClick={() => setMobileMenu((value) => !value)} className="grid h-10 w-10 place-items-center rounded-full border border-line" aria-label="Toggle admin menu">{mobileMenu ? <X size={18}/> : <Menu size={18}/>}</button>
      </header>
      <aside className={`fixed inset-y-0 left-0 z-50 w-64 border-r border-burgundy-dark bg-burgundy px-4 py-6 text-white transition-transform lg:translate-x-0 ${mobileMenu ? 'translate-x-0' : '-translate-x-full'}`}>
        <div className="px-2"><Logo light /><p className="mt-3 text-[9px] uppercase tracking-[.16em] text-ivory/45">Administrator office</p></div>
        <nav className="mt-9 space-y-1" aria-label="Admin sections">{nav.map(({ id, label, icon: Icon }) => <button key={id} onClick={() => { setTab(id); setMobileMenu(false) }} className={`flex w-full items-center gap-3 rounded-xl px-3 py-3 text-left text-sm transition-colors ${tab === id ? 'bg-white text-burgundy' : 'text-ivory/65 hover:bg-white/10 hover:text-white'}`}><Icon size={17}/>{label}<ChevronRight size={14} className="ml-auto opacity-45"/></button>)}</nav>
        <div className="absolute inset-x-4 bottom-5 border-t border-white/15 pt-4"><p className="truncate px-2 text-xs text-ivory/65">{user.email}</p><div className="mt-3 flex gap-2"><Link to="/" className="flex-1 rounded-lg border border-white/20 px-3 py-2 text-center text-[9px] uppercase tracking-wider text-ivory/70 hover:text-white">View store</Link><button onClick={logout} className="grid h-9 w-9 place-items-center rounded-lg border border-white/20 text-ivory/70 hover:text-white" aria-label="Sign out"><LogOut size={15}/></button></div></div>
      </aside>
      {mobileMenu && <button className="fixed inset-0 z-40 bg-ink/35 lg:hidden" onClick={() => setMobileMenu(false)} aria-label="Close admin menu" />}

      <main className="min-h-screen p-4 sm:p-6 lg:ml-64 lg:p-8">
        <div className="mx-auto max-w-7xl">
          <div className="mb-7 flex items-end justify-between"><div><p className="eyebrow">SCARLET administration</p><h1 className="mt-1 font-display text-4xl">{nav.find((item) => item.id === tab)?.label}</h1></div><button onClick={() => void loadAll(token).then(() => addToast('Dashboard refreshed.')).catch((e) => addToast(e.message, 'error'))} className="chip hidden sm:inline-flex">Refresh</button></div>

          {tab === 'overview' && stats && <Overview stats={stats} onOpenOrders={() => setTab('orders')} />}

          {tab === 'products' && (
            <div className="space-y-6">
              <section className="overflow-hidden rounded-2xl border border-line bg-white shadow-card">
                <div className="flex flex-col gap-3 border-b border-line p-5 sm:flex-row sm:items-center sm:justify-between"><div><h2 className="font-display text-2xl">Catalogue</h2><p className="mt-1 text-xs text-muted">{products.length} product records · inactive products remain in order history.</p></div><button onClick={() => setEditing(blankProduct(categories[0]?.slug))} className="btn-primary !py-2.5"><Plus size={14}/> Add product</button></div>
                <div className="overflow-x-auto"><table className="admin-table w-full min-w-[800px]"><thead><tr><th>Product</th><th>Category</th><th>Price</th><th>Stock</th><th>Status</th><th></th></tr></thead><tbody>{products.map((product) => <tr key={product.id} className={!product.is_active ? 'opacity-55' : ''}><td><div className="flex items-center gap-3"><img src={product.image_url} alt="" className="h-11 w-11 rounded-lg border border-line object-cover"/><div><p className="font-medium">{product.name}</p><p className="mt-0.5 text-[10px] text-muted">/{product.slug}</p></div></div></td><td className="text-muted">{categories.find((category) => category.slug === product.category)?.name || product.category}</td><td>{formatPKR(product.price_pkr)}</td><td><span className={product.stock_quantity <= 5 ? 'font-medium text-burgundy' : ''}>{product.stock_quantity}</span></td><td><span className={`rounded-full px-2.5 py-1 text-[9px] uppercase tracking-wider ${product.is_active ? 'bg-[#EAF4EB] text-[#4F805D]' : 'bg-stone-100 text-muted'}`}>{product.is_active ? 'Active' : 'Inactive'}</span></td><td><button onClick={() => setEditing(product)} className="grid h-8 w-8 place-items-center rounded-full border border-line hover:bg-blush" aria-label={`Edit ${product.name}`}><Edit3 size={14}/></button></td></tr>)}</tbody></table></div>
              </section>

              <section className="rounded-2xl border border-line bg-white p-5 shadow-card"><div className="flex flex-col gap-6 lg:grid lg:grid-cols-[1fr_1.1fr]"><div><p className="eyebrow">Organisation</p><h2 className="mt-1 font-display text-2xl">Categories</h2><div className="mt-4 flex flex-wrap gap-2">{categories.map((category) => <button key={category.slug} onClick={() => setCategoryDraft({ original: category.slug, slug: category.slug, name: category.name, description: category.description || '' })} className="chip">{category.name} <Edit3 size={10}/></button>)}</div></div><form onSubmit={saveCategory} className="grid gap-3 rounded-xl bg-cream/60 p-4 sm:grid-cols-2"><label><span className="label">Category name</span><input className="input" required value={categoryDraft.name} onChange={(e) => setCategoryDraft((current) => ({ ...current, name: e.target.value, slug: current.original ? current.slug : slugify(e.target.value) }))}/></label><label><span className="label">Slug</span><input className="input" required pattern="[a-z0-9-]+" value={categoryDraft.slug} onChange={(e) => setCategoryDraft((current) => ({ ...current, slug: slugify(e.target.value) }))}/></label><label className="sm:col-span-2"><span className="label">Description</span><input className="input" value={categoryDraft.description} onChange={(e) => setCategoryDraft((current) => ({ ...current, description: e.target.value }))}/></label><div className="flex gap-2 sm:col-span-2"><button className="btn-primary !py-2.5"><Save size={13}/> {categoryDraft.original ? 'Update category' : 'Add category'}</button>{categoryDraft.original && <button type="button" onClick={() => setCategoryDraft({ original: null, slug: '', name: '', description: '' })} className="btn-ghost !py-2.5">Cancel</button>}</div></form></div></section>
            </div>
          )}

          {tab === 'orders' && (
            <section className="overflow-hidden rounded-2xl border border-line bg-white shadow-card"><div className="border-b border-line p-5"><h2 className="font-display text-2xl">Order queue</h2><p className="mt-1 text-xs text-muted">Customer details are visible only through this authenticated API.</p></div><div className="overflow-x-auto"><table className="admin-table w-full min-w-[1050px]"><thead><tr><th>Order</th><th>Customer</th><th>Items</th><th>Total</th><th>Payment</th><th>Fulfilment</th><th>Created</th></tr></thead><tbody>{orders.map((order) => <tr key={order.id}><td><details><summary className="cursor-pointer font-medium text-burgundy">{order.order_number}</summary><div className="mt-2 w-64 rounded-lg bg-cream p-3 text-xs leading-relaxed text-muted"><p>{order.address}</p><p>{order.city}, {order.postal_code}</p>{order.notes && <p className="mt-2">Note: {order.notes}</p>}</div></details></td><td><p>{order.customer_name}</p><p className="text-xs text-muted">{order.email}</p><p className="text-xs text-muted">{order.phone}</p></td><td><div className="max-w-[220px] space-y-1">{order.items?.map((item) => <p key={item.id} className="truncate text-xs">{item.quantity}× {item.name}</p>)}</div></td><td className="font-medium">{formatPKR(order.total_pkr)}</td><td><select className="rounded-lg border border-line bg-white px-2 py-2 text-xs" value={order.payment_status} onChange={(e) => void updateOrder(order.id, { payment_status: e.target.value })}><option value="unpaid">Unpaid</option><option value="pending">Pending</option><option value="paid">Paid</option><option value="failed">Failed</option></select><p className="mt-1 text-[9px] text-muted">{order.payment_method.replaceAll('_',' ')}</p></td><td><select className="rounded-lg border border-line bg-white px-2 py-2 text-xs" value={order.status} onChange={(e) => void updateOrder(order.id, { status: e.target.value })}><option value="pending">Pending</option><option value="confirmed">Confirmed</option><option value="in_production">In production</option><option value="shipped">Shipped</option><option value="delivered">Delivered</option><option value="cancelled">Cancelled</option></select></td><td className="text-xs text-muted">{new Date(`${order.created_at}Z`).toLocaleDateString()}</td></tr>)}</tbody></table>{orders.length === 0 && <p className="p-10 text-center text-sm text-muted">No orders have been recorded.</p>}</div></section>
          )}

          {tab === 'settings' && settings && (
            <form onSubmit={saveSettings} className="max-w-3xl space-y-6"><section className="rounded-2xl border border-line bg-white p-5 shadow-card sm:p-7"><p className="eyebrow">Pricing rules</p><h2 className="mt-1 font-display text-2xl">Money & delivery</h2><div className="mt-5 grid gap-4 sm:grid-cols-2">{([['chain_base_price_pkr','Chain base price (PKR)'],['standard_shipping_pkr','Standard shipping (PKR)'],['express_shipping_pkr','Express shipping (PKR)'],['free_shipping_threshold_pkr','Free standard threshold (PKR)'],['tax_rate_pct','Tax rate (%)']] as const).map(([key,label]) => <label key={key}><span className="label">{label}</span><input type="number" min="0" className="input" value={settings[key]} onChange={(e) => setSettings({ ...settings, [key]: Number(e.target.value) })}/></label>)}</div></section><section className="rounded-2xl border border-line bg-white p-5 shadow-card sm:p-7"><p className="eyebrow">Public details</p><h2 className="mt-1 font-display text-2xl">Store configuration</h2><div className="mt-5 grid gap-4 sm:grid-cols-2"><label className="sm:col-span-2"><span className="label">Announcement bar</span><input className="input" value={settings.announcement} onChange={(e) => setSettings({ ...settings, announcement: e.target.value })}/></label><label><span className="label">Store email</span><input type="email" className="input" value={settings.store_email} onChange={(e) => setSettings({ ...settings, store_email: e.target.value })}/></label><label><span className="label">Store phone</span><input className="input" value={settings.store_phone} onChange={(e) => setSettings({ ...settings, store_phone: e.target.value })}/></label><label className="sm:col-span-2"><span className="label">Store address</span><input className="input" value={settings.store_address} onChange={(e) => setSettings({ ...settings, store_address: e.target.value })}/></label><label className="sm:col-span-2"><span className="label">WhatsApp number (international digits only; blank disables link)</span><input className="input" value={settings.whatsapp_number} onChange={(e) => setSettings({ ...settings, whatsapp_number: e.target.value.replace(/[^\d+]/g,'') })} placeholder="Not configured"/></label></div><div className="mt-5 rounded-xl bg-blush/55 p-4 text-xs leading-relaxed text-muted">All current contact details are labelled demo placeholders. Replace them with verified business information. A blank WhatsApp number preserves the visible help button without linking to an invented telephone number.</div></section><button className="btn-primary"><Save size={15}/> Save settings</button></form>
          )}
        </div>
      </main>
      {editing && <ProductEditor product={editing} categories={categories} token={token} onClose={() => setEditing(null)} onSave={saveProduct} />}
      <ToastViewport />
    </div>
  )
}

function AdminLogin({ onLogin }: { onLogin: (email: string, password: string) => Promise<void> }) {
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [busy, setBusy] = useState(false)
  const [error, setError] = useState('')
  async function submit(event: FormEvent) { event.preventDefault(); setBusy(true); setError(''); try { await onLogin(email, password) } catch (reason) { setError(reason instanceof Error ? reason.message : 'Sign in failed.'); setBusy(false) } }
  return <div className="grid min-h-screen bg-cream p-4 lg:grid-cols-2"><div className="hidden rounded-3xl bg-burgundy p-12 text-ivory lg:flex lg:flex-col lg:justify-between"><Logo light/><div><p className="eyebrow !text-rose">Protected workspace</p><h1 className="mt-3 font-display text-5xl leading-tight">Behind the<br/>charm case.</h1><p className="mt-5 max-w-md text-sm leading-7 text-ivory/60">Manage products, demo inventory, orders, fulfilment status and public store settings through server-authorised routes.</p></div><p className="text-[9px] uppercase tracking-[.14em] text-ivory/35">SCARLET administration · Role protected</p></div><div className="flex items-center justify-center px-2 py-12 sm:px-8"><div className="w-full max-w-md"><div className="lg:hidden"><Logo/></div><p className="eyebrow mt-8 lg:mt-0">Administrator access</p><h1 className="mt-2 font-display text-4xl">Welcome back</h1><p className="mt-2 text-sm text-muted">Sign in with an administrator account configured on the server.</p><form onSubmit={submit} className="mt-7 space-y-4"><label><span className="label">Admin email</span><input type="email" autoComplete="username" required className="input" value={email} onChange={(e) => setEmail(e.target.value)}/></label><label><span className="label">Password</span><input type="password" autoComplete="current-password" required minLength={8} className="input" value={password} onChange={(e) => setPassword(e.target.value)}/></label>{error && <p className="text-sm text-burgundy" role="alert">{error}</p>}<button disabled={busy} className="btn-primary w-full">{busy ? 'Verifying…' : 'Sign in securely'}</button></form>{import.meta.env.DEV && <details className="mt-5 rounded-xl border border-gold/30 bg-white p-4 text-xs text-muted"><summary className="cursor-pointer font-medium text-ink">Local development credentials</summary><p className="mt-2">Email: <code>admin@scarlet.demo</code><br/>Password: <code>ScarletDemo2026!</code></p><p className="mt-2 text-burgundy">Development only. Set ADMIN_EMAIL, ADMIN_PASSWORD and JWT_SECRET before deployment.</p></details>}<Link to="/" className="mt-6 inline-flex text-[10px] uppercase tracking-[.14em] text-burgundy">← Return to storefront</Link></div></div></div>
}

function Overview({ stats, onOpenOrders }: { stats: StatsData; onOpenOrders: () => void }) {
  const cards = [[Box,'Active products',stats.stats.productCount],[ShoppingBag,'Orders recorded',stats.stats.orderCount],[BarChart3,'Recorded order value',formatPKR(stats.stats.revenuePkr)],[Package,'Low stock',stats.stats.lowStock.length]]
  return <div className="space-y-6"><div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">{cards.map(([Icon,label,value]) => { const C=Icon as typeof Box; return <div key={String(label)} className="rounded-2xl border border-line bg-white p-5 shadow-card"><span className="grid h-10 w-10 place-items-center rounded-xl bg-blush text-burgundy"><C size={18}/></span><p className="mt-5 text-[10px] uppercase tracking-[.14em] text-muted">{String(label)}</p><p className="mt-1 font-display text-3xl font-semibold">{String(value)}</p></div>})}</div><div className="grid gap-6 xl:grid-cols-[1.3fr_.7fr]"><section className="rounded-2xl border border-line bg-white shadow-card"><div className="flex items-center justify-between border-b border-line p-5"><h2 className="font-display text-2xl">Recent orders</h2><button onClick={onOpenOrders} className="text-[9px] uppercase tracking-wider text-burgundy">View all →</button></div><div className="divide-y divide-line">{stats.recentOrders.map((order) => <div key={order.id} className="grid grid-cols-[1fr_auto] gap-4 p-4 sm:grid-cols-[1fr_1fr_auto]"><div><p className="text-sm font-medium">{order.order_number}</p><p className="text-xs text-muted">{order.customer_name}</p></div><p className="hidden self-center text-xs capitalize text-muted sm:block">{order.status.replaceAll('_',' ')}</p><p className="self-center font-medium text-burgundy">{formatPKR(order.total_pkr)}</p></div>)}{stats.recentOrders.length===0&&<p className="p-8 text-center text-sm text-muted">No orders yet.</p>}</div></section><section className="rounded-2xl border border-line bg-white p-5 shadow-card"><h2 className="font-display text-2xl">Low stock</h2><p className="mt-1 text-xs text-muted">Active products at five or fewer.</p><div className="mt-4 divide-y divide-line">{stats.stats.lowStock.map((product)=><div key={product.id} className="flex items-center justify-between py-3"><div className="flex items-center gap-2"><img src={product.image_url} alt="" className="h-9 w-9 rounded-lg object-cover"/><p className="max-w-[160px] truncate text-xs">{product.name}</p></div><span className="font-medium text-burgundy">{product.stock_quantity}</span></div>)}{stats.stats.lowStock.length===0&&<p className="py-8 text-center text-sm text-muted">Nothing is low.</p>}</div></section></div></div>
}

function ProductEditor({ product: initial, categories, token, onClose, onSave }: { product: Partial<Product>; categories: Category[]; token: string; onClose: () => void; onSave: (product: Partial<Product>) => Promise<void> }) {
  const [product, setProduct] = useState(initial)
  const [busy, setBusy] = useState(false)
  const [uploading, setUploading] = useState(false)
  const addToast = useUiStore((state) => state.addToast)
  async function submit(event: FormEvent) { event.preventDefault(); setBusy(true); try { await onSave(product) } finally { setBusy(false) } }
  async function upload(file?: File) { if(!file)return; setUploading(true); try { const {url}=await api.admin.uploadImage(token,file); setProduct({...product,image_url:url}); addToast('Image uploaded. Save the product to keep the change.') } catch(error){addToast(error instanceof Error?error.message:'Upload failed.','error')} finally{setUploading(false)} }
  const text = (key: keyof Product, label: string, extra = '') => <label className={extra}><span className="label">{label}</span><input className="input" required value={String(product[key] ?? '')} onChange={(e) => setProduct({...product,[key]:e.target.value})}/></label>
  return <div className="fixed inset-0 z-[100] flex justify-end bg-ink/35 backdrop-blur-[1px]" role="presentation" onMouseDown={(e)=>{if(e.target===e.currentTarget)onClose()}}><aside className="h-full w-full max-w-2xl overflow-y-auto bg-ivory p-5 shadow-2xl sm:p-7" role="dialog" aria-modal="true" aria-labelledby="product-editor-title"><div className="flex items-start justify-between"><div><p className="eyebrow">Catalogue editor</p><h2 id="product-editor-title" className="mt-1 font-display text-3xl">{product.id?'Edit product':'New product'}</h2></div><button onClick={onClose} className="grid h-9 w-9 place-items-center rounded-full border border-line" aria-label="Close editor"><X size={16}/></button></div><form onSubmit={submit} className="mt-7 grid gap-4 sm:grid-cols-2">{text('name','Product name')}<label><span className="label">Slug</span><input className="input" required pattern="[a-z0-9-]+" value={product.slug||''} onChange={(e)=>setProduct({...product,slug:slugify(e.target.value)})}/></label><label className="sm:col-span-2"><span className="label">Description</span><textarea className="input min-h-24" required minLength={10} value={product.description||''} onChange={(e)=>setProduct({...product,description:e.target.value})}/></label><label><span className="label">Category</span><select className="input" required value={product.category||''} onChange={(e)=>setProduct({...product,category:e.target.value})}>{categories.map((category)=><option key={category.slug} value={category.slug}>{category.name}</option>)}</select></label><label><span className="label">Price (PKR)</span><input type="number" min="0" step="1" className="input" required value={product.price_pkr??0} onChange={(e)=>setProduct({...product,price_pkr:Number(e.target.value)})}/></label><label><span className="label">Stock quantity</span><input type="number" min="0" step="1" className="input" required value={product.stock_quantity??0} onChange={(e)=>setProduct({...product,stock_quantity:Number(e.target.value)})}/></label>{text('alt_text','Image alt text')}<label className="sm:col-span-2"><span className="label">Image URL</span><div className="flex gap-2"><input className="input" required value={product.image_url||''} onChange={(e)=>setProduct({...product,image_url:e.target.value})}/><label className="btn-ghost !cursor-pointer !px-4 !py-2"><ImagePlus size={15}/>{uploading?'Uploading…':'Upload'}<input type="file" accept="image/png,image/jpeg,image/webp" className="sr-only" disabled={uploading} onChange={(e)=>void upload(e.target.files?.[0])}/></label></div></label>{product.image_url&&<div className="sm:col-span-2"><img src={product.image_url} alt="Preview" className="h-32 w-32 rounded-xl border border-line object-cover"/></div>}{text('material','Material / specification')}{text('finish','Finish')}<div className="flex flex-wrap gap-4 sm:col-span-2">{([['is_active','Active'],['is_featured','Featured'],['is_new','New arrival']] as const).map(([key,label])=><label key={key} className="inline-flex items-center gap-2 text-sm"><input type="checkbox" checked={Boolean(product[key])} onChange={(e)=>setProduct({...product,[key]:e.target.checked})} className="accent-[#8D1528]"/>{label}</label>)}</div><div className="mt-2 flex gap-2 border-t border-line pt-5 sm:col-span-2"><button disabled={busy} className="btn-primary"><Save size={14}/>{busy?'Saving…':'Save product'}</button><button type="button" onClick={onClose} className="btn-ghost">Cancel</button></div></form></aside></div>
}
