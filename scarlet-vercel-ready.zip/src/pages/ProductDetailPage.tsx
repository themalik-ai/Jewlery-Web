import { useEffect, useState } from 'react'
import { Link, useNavigate, useParams } from 'react-router-dom'
import { ArrowLeft, Check, Gem, Minus, Plus, ShieldCheck, ShoppingBag, Sparkles } from 'lucide-react'
import { api } from '../lib/api'
import type { Product } from '../lib/types'
import { formatPKR } from '../config/store'
import { usePageTitle } from '../lib/hooks'
import { useCartStore } from '../store/cartStore'
import { useEditorStore } from '../store/editorStore'
import { useUiStore } from '../store/uiStore'
import { ProductGrid } from '../components/products/ProductGrid'

export default function ProductDetailPage() {
  const { slug = '' } = useParams()
  const navigate = useNavigate()
  const [product, setProduct] = useState<Product | null>(null)
  const [related, setRelated] = useState<Product[]>([])
  const [quantity, setQuantity] = useState(1)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)
  const addProduct = useCartStore((state) => state.addProduct)
  const setDesignQuantity = useEditorStore((state) => state.setProductQuantity)
  const currentDesignQuantity = useEditorStore((state) => product ? state.instances.filter((instance) => instance.productId === product.id).length : 0)
  const addToast = useUiStore((state) => state.addToast)
  usePageTitle(product?.name || 'Charm Detail', product?.description)

  useEffect(() => {
    let active = true
    setLoading(true)
    setError(null)
    api.product(slug)
      .then((data) => { if (active) { setProduct(data.product); setRelated(data.related); setQuantity(1); setLoading(false) } })
      .catch((reason) => { if (active) { setError(reason instanceof Error ? reason.message : 'Product unavailable.'); setLoading(false) } })
    return () => { active = false }
  }, [slug])

  if (loading) return <div className="mx-auto max-w-7xl px-5 py-12 sm:px-6 lg:px-8"><div className="grid gap-10 lg:grid-cols-2"><div className="skeleton aspect-square rounded-3xl" /><div className="space-y-5 pt-10"><div className="skeleton h-3 w-28 rounded" /><div className="skeleton h-14 w-4/5 rounded" /><div className="skeleton h-6 w-28 rounded" /><div className="skeleton h-20 w-full rounded" /></div></div></div>

  if (error || !product) return (
    <div className="mx-auto max-w-xl px-5 py-24 text-center"><p className="eyebrow">Not found</p><h1 className="mt-3 font-display text-4xl">This charm slipped away.</h1><p className="mt-3 text-sm text-muted">{error}</p><Link to="/shop" className="btn-primary mt-6"><ArrowLeft size={15} /> Return to the charm case</Link></div>
  )

  const available = product.stock_quantity > 0
  return (
    <>
      <div className="mx-auto max-w-7xl px-5 py-5 sm:px-6 lg:px-8">
        <nav aria-label="Breadcrumb" className="flex items-center gap-2 text-[9px] uppercase tracking-[0.14em] text-muted"><Link to="/shop" className="hover:text-burgundy">Charm case</Link><span>/</span><span className="truncate text-ink">{product.name}</span></nav>
      </div>
      <section className="mx-auto max-w-7xl px-5 pb-14 sm:px-6 lg:px-8 lg:pb-20">
        <div className="grid gap-9 lg:grid-cols-2 lg:gap-16">
          <div className="relative overflow-hidden rounded-3xl border border-line bg-cream">
            <img src={product.image_url} alt={product.alt_text} className="aspect-square w-full object-cover" />
            <span className="absolute left-4 top-4 rounded-full border border-white/70 bg-white/80 px-3 py-1.5 text-[8px] uppercase tracking-[0.15em] text-burgundy backdrop-blur">Original demo artwork</span>
          </div>

          <div className="flex flex-col justify-center lg:pr-8">
            <p className="eyebrow">{product.category.replaceAll('-', ' ')}</p>
            <h1 className="mt-3 font-display text-4xl leading-[1.06] sm:text-5xl">{product.name}</h1>
            <p className="mt-4 font-display text-3xl font-semibold text-burgundy">{formatPKR(product.price_pkr)}</p>
            <div className="mt-4 flex items-center gap-2 text-[10px] uppercase tracking-[0.12em] text-muted">
              {available ? <><Check size={14} className="text-[#568264]" /> In demo stock · {product.stock_quantity} shown</> : <>Currently unavailable</>}
            </div>
            <p className="mt-6 text-sm leading-7 text-muted">{product.description}</p>

            <div className="mt-7 flex items-center gap-3">
              <span className="text-[10px] uppercase tracking-[0.14em] text-muted">Quantity</span>
              <div className="qty-pill !rounded-full">
                <button onClick={() => setQuantity(Math.max(1, quantity - 1))} disabled={quantity <= 1} aria-label="Decrease quantity"><Minus size={13} /></button>
                <span className="!min-w-[30px]">{quantity}</span>
                <button onClick={() => setQuantity(Math.min(product.stock_quantity, quantity + 1))} disabled={quantity >= Math.min(product.stock_quantity, 20)} aria-label="Increase quantity"><Plus size={13} /></button>
              </div>
            </div>

            <div className="mt-7 grid gap-2.5 sm:grid-cols-2">
              <button disabled={!available} className="btn-primary" onClick={() => { addProduct(product, quantity); addToast(`${quantity} × ${product.name} added to your bag.`) }}><ShoppingBag size={16} /> Add to bag</button>
              <button disabled={!available} className="btn-outline" onClick={() => { setDesignQuantity(product.id, Math.min(12, currentDesignQuantity + quantity)); addToast(`${quantity} × ${product.name} added to your design.`); navigate('/builder') }}><Gem size={16} /> Add to design</button>
            </div>

            <div className="mt-8 divide-y divide-line rounded-2xl border border-line bg-white px-4">
              <div className="grid grid-cols-[100px_1fr] gap-3 py-3.5 text-xs"><span className="text-muted">Material</span><span>{product.material}</span></div>
              <div className="grid grid-cols-[100px_1fr] gap-3 py-3.5 text-xs"><span className="text-muted">Finish</span><span>{product.finish}</span></div>
              <div className="grid grid-cols-[100px_1fr] gap-3 py-3.5 text-xs"><span className="text-muted">Listing status</span><span className="text-burgundy">Illustrative demo — verify before sale</span></div>
            </div>
            <div className="mt-5 flex gap-3 rounded-xl bg-petal/60 p-4 text-xs leading-relaxed text-muted"><ShieldCheck size={18} className="mt-0.5 shrink-0 text-burgundy" /><p>Prices are rechecked by the server at order creation. Material and finish claims shown here are explicitly unverified demo specifications.</p></div>
          </div>
        </div>
      </section>

      {related.length > 0 && (
        <section className="border-t border-line bg-petal/40 py-14 lg:py-18">
          <div className="mx-auto max-w-7xl px-5 sm:px-6 lg:px-8">
            <div className="mb-7 text-center"><Sparkles className="mx-auto text-gold" size={18} /><p className="eyebrow mt-3">Keep exploring</p><h2 className="section-title mt-2">Made to mingle</h2></div>
            <ProductGrid products={related} mode="shop" />
          </div>
        </section>
      )}
    </>
  )
}
