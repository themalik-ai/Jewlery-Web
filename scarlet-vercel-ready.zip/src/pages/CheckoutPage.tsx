import { FormEvent, useMemo, useRef, useState } from 'react'
import { Link, useNavigate } from 'react-router-dom'
import { AlertCircle, Banknote, Check, ChevronLeft, CreditCard, Lock, Package, Truck } from 'lucide-react'
import { api, ApiRequestError } from '../lib/api'
import { formatPKR } from '../config/store'
import { usePageTitle } from '../lib/hooks'
import { cartSubtotal, lineTotal, useCartStore } from '../store/cartStore'
import { useSettingsStore } from '../store/settingsStore'
import { MiniNecklaceFromCart } from '../components/builder/MiniNecklace'
import { EmptyState } from '../components/ui/EmptyState'

type Fields = {
  name: string; email: string; phone: string; address: string; city: string; postalCode: string; notes: string
}
type FieldErrors = Partial<Record<keyof Fields | 'form' | 'terms', string>>

export default function CheckoutPage() {
  usePageTitle('Checkout')
  const navigate = useNavigate()
  const lines = useCartStore((state) => state.lines)
  const clearCart = useCartStore((state) => state.clear)
  const settings = useSettingsStore((state) => state.settings)
  const [fields, setFields] = useState<Fields>({ name: '', email: '', phone: '', address: '', city: 'Lahore', postalCode: '', notes: '' })
  const [shippingMethod, setShippingMethod] = useState<'standard' | 'express'>('standard')
  const [paymentMethod, setPaymentMethod] = useState<'cash_on_delivery' | 'bank_transfer'>('cash_on_delivery')
  const [terms, setTerms] = useState(false)
  const [errors, setErrors] = useState<FieldErrors>({})
  const [busy, setBusy] = useState(false)
  const idempotencyKey = useRef(typeof crypto !== 'undefined' && 'randomUUID' in crypto ? crypto.randomUUID() : `${Date.now()}-${Math.random()}-checkout`)

  const subtotal = useMemo(() => cartSubtotal(lines), [lines])
  const shipping = shippingMethod === 'express'
    ? settings.express_shipping_pkr
    : subtotal >= settings.free_shipping_threshold_pkr ? 0 : settings.standard_shipping_pkr
  const tax = Math.round(((subtotal + shipping) * settings.tax_rate_pct) / 100)
  const total = subtotal + shipping + tax

  if (lines.length === 0) return <div className="mx-auto max-w-7xl px-5 py-10 sm:px-6 lg:px-8"><EmptyState icon={Package} title="There’s nothing to check out" description="Your shopping bag is empty. Choose a charm or build your necklace first." action="Open the necklace studio" to="/builder" /></div>

  function update<K extends keyof Fields>(key: K, value: Fields[K]) {
    setFields((current) => ({ ...current, [key]: value }))
    if (errors[key]) setErrors((current) => ({ ...current, [key]: undefined, form: undefined }))
  }

  function validate() {
    const next: FieldErrors = {}
    if (fields.name.trim().length < 2) next.name = 'Enter your full name.'
    if (!/^\S+@\S+\.\S+$/.test(fields.email.trim())) next.email = 'Enter a valid email address.'
    if (fields.phone.replace(/\D/g, '').length < 7) next.phone = 'Enter a valid phone number.'
    if (fields.address.trim().length < 8) next.address = 'Enter a complete delivery address.'
    if (fields.city.trim().length < 2) next.city = 'Enter your city.'
    if (fields.postalCode.trim().length < 3) next.postalCode = 'Enter a postal code.'
    if (!terms) next.terms = 'Please accept the demo terms to continue.'
    setErrors(next)
    if (Object.keys(next).length) document.querySelector<HTMLElement>('[aria-invalid="true"]')?.focus()
    return Object.keys(next).length === 0
  }

  async function submit(event: FormEvent) {
    event.preventDefault()
    if (!validate()) return
    setBusy(true)
    setErrors({})
    const items = lines.map((line) => line.type === 'product'
      ? { type: 'product' as const, productId: line.productId, quantity: line.quantity }
      : { type: 'necklace' as const, positions: line.positions })
    try {
      const result = await api.createOrder({
        customer: fields,
        shippingMethod,
        paymentMethod,
        items,
      }, idempotencyKey.current)
      sessionStorage.setItem(`scarlet-order-${result.order.order_number}`, JSON.stringify(result))
      clearCart()
      navigate(`/order-confirmation/${result.order.order_number}`, { state: result, replace: true })
    } catch (reason) {
      if (reason instanceof ApiRequestError) {
        const mapped: FieldErrors = { form: reason.message }
        for (const [key, value] of Object.entries(reason.details || {})) {
          const short = key.replace('customer.', '') as keyof Fields
          if (short in fields) mapped[short] = value
        }
        setErrors(mapped)
      } else {
        setErrors({ form: reason instanceof Error ? reason.message : 'The order could not be placed.' })
      }
      window.scrollTo({ top: 0, behavior: 'smooth' })
    } finally {
      setBusy(false)
    }
  }

  const input = (key: keyof Fields, label: string, type = 'text', attrs: Record<string, string> = {}) => (
    <label className={key === 'address' || key === 'notes' ? 'sm:col-span-2' : ''}>
      <span className="label">{label}</span>
      {key === 'notes' ? (
        <textarea value={fields[key]} onChange={(e) => update(key, e.target.value)} className="input min-h-24 resize-y" maxLength={500} placeholder="Optional delivery note" />
      ) : (
        <input type={type} value={fields[key]} onChange={(e) => update(key, e.target.value)} className={`input ${errors[key] ? '!border-burgundy !ring-1 !ring-burgundy/20' : ''}`} aria-invalid={Boolean(errors[key])} aria-describedby={errors[key] ? `${key}-error` : undefined} required {...attrs} />
      )}
      {errors[key] && <span id={`${key}-error`} className="mt-1 block text-xs text-burgundy">{errors[key]}</span>}
    </label>
  )

  return (
    <>
      <div className="border-b border-line bg-white">
        <div className="mx-auto flex max-w-7xl items-center justify-between px-5 py-4 sm:px-6 lg:px-8">
          <Link to="/cart" className="inline-flex items-center gap-1.5 text-[10px] uppercase tracking-[0.14em] text-muted hover:text-burgundy"><ChevronLeft size={14} /> Back to bag</Link>
          <span className="inline-flex items-center gap-1.5 text-[9px] uppercase tracking-[0.14em] text-muted"><Lock size={12} /> Validated order form</span>
        </div>
      </div>
      <form onSubmit={submit} noValidate>
        <div className="mx-auto grid max-w-7xl gap-10 px-5 py-10 sm:px-6 lg:grid-cols-[1fr_420px] lg:px-8 lg:py-14">
          <div className="max-w-2xl">
            <p className="eyebrow">Almost there</p><h1 className="mt-2 font-display text-4xl sm:text-5xl">Checkout</h1>
            <div className="mt-5 flex gap-3 rounded-xl border border-gold/35 bg-cream p-4 text-xs leading-relaxed text-muted">
              <AlertCircle size={18} className="mt-0.5 shrink-0 text-gold" />
              <p><strong className="text-ink">Offline checkout demo.</strong> No card gateway is configured and no online payment will be taken. The backend records a real local demo order with authoritative catalogue prices.</p>
            </div>
            {errors.form && <div className="mt-4 flex gap-2 rounded-xl border border-burgundy/30 bg-blush p-4 text-sm text-burgundy" role="alert"><AlertCircle size={18} className="shrink-0" />{errors.form}</div>}

            <section className="mt-9" aria-labelledby="delivery-title">
              <div className="flex items-center gap-3"><span className="grid h-8 w-8 place-items-center rounded-full bg-burgundy text-xs text-white">1</span><h2 id="delivery-title" className="font-display text-2xl font-semibold">Delivery details</h2></div>
              <div className="mt-5 grid gap-4 sm:grid-cols-2">
                {input('name', 'Full name', 'text', { autoComplete: 'name' })}
                {input('email', 'Email address', 'email', { autoComplete: 'email' })}
                {input('phone', 'Phone number', 'tel', { autoComplete: 'tel', placeholder: '+92…' })}
                {input('city', 'City', 'text', { autoComplete: 'address-level2' })}
                {input('address', 'Delivery address', 'text', { autoComplete: 'street-address' })}
                {input('postalCode', 'Postal code', 'text', { autoComplete: 'postal-code' })}
                {input('notes', 'Order note (optional)')}
              </div>
            </section>

            <section className="mt-10" aria-labelledby="shipping-title">
              <div className="flex items-center gap-3"><span className="grid h-8 w-8 place-items-center rounded-full bg-burgundy text-xs text-white">2</span><h2 id="shipping-title" className="font-display text-2xl font-semibold">Shipping method</h2></div>
              <div className="mt-5 grid gap-3 sm:grid-cols-2">
                <label className={`flex cursor-pointer gap-3 rounded-xl border p-4 transition-colors ${shippingMethod === 'standard' ? 'border-burgundy bg-blush/40' : 'border-line bg-white hover:border-rose'}`}>
                  <input type="radio" name="shipping" checked={shippingMethod === 'standard'} onChange={() => setShippingMethod('standard')} className="mt-1 accent-[#8D1528]" />
                  <Truck size={19} className="mt-0.5 shrink-0 text-burgundy" />
                  <span className="flex-1"><span className="block text-sm font-medium">Standard delivery</span><span className="mt-1 block text-xs text-muted">Timeline must be configured by the store owner.</span><span className="mt-2 block text-xs font-medium text-burgundy">{subtotal >= settings.free_shipping_threshold_pkr ? 'Complimentary' : formatPKR(settings.standard_shipping_pkr)}</span></span>
                </label>
                <label className={`flex cursor-pointer gap-3 rounded-xl border p-4 transition-colors ${shippingMethod === 'express' ? 'border-burgundy bg-blush/40' : 'border-line bg-white hover:border-rose'}`}>
                  <input type="radio" name="shipping" checked={shippingMethod === 'express'} onChange={() => setShippingMethod('express')} className="mt-1 accent-[#8D1528]" />
                  <Package size={19} className="mt-0.5 shrink-0 text-burgundy" />
                  <span className="flex-1"><span className="block text-sm font-medium">Express delivery</span><span className="mt-1 block text-xs text-muted">Timeline must be confirmed before launch.</span><span className="mt-2 block text-xs font-medium text-burgundy">{formatPKR(settings.express_shipping_pkr)}</span></span>
                </label>
              </div>
            </section>

            <section className="mt-10" aria-labelledby="payment-title">
              <div className="flex items-center gap-3"><span className="grid h-8 w-8 place-items-center rounded-full bg-burgundy text-xs text-white">3</span><h2 id="payment-title" className="font-display text-2xl font-semibold">Offline payment method</h2></div>
              <div className="mt-5 space-y-3">
                <label className={`flex cursor-pointer gap-3 rounded-xl border p-4 ${paymentMethod === 'cash_on_delivery' ? 'border-burgundy bg-blush/40' : 'border-line bg-white'}`}>
                  <input type="radio" name="payment" checked={paymentMethod === 'cash_on_delivery'} onChange={() => setPaymentMethod('cash_on_delivery')} className="mt-1 accent-[#8D1528]" />
                  <Banknote size={19} className="mt-0.5 shrink-0 text-burgundy" /><span><span className="block text-sm font-medium">Cash on delivery</span><span className="mt-1 block text-xs leading-relaxed text-muted">Records the order as unpaid. Availability and handling must be approved by the merchant.</span></span>
                </label>
                <label className={`flex cursor-pointer gap-3 rounded-xl border p-4 ${paymentMethod === 'bank_transfer' ? 'border-burgundy bg-blush/40' : 'border-line bg-white'}`}>
                  <input type="radio" name="payment" checked={paymentMethod === 'bank_transfer'} onChange={() => setPaymentMethod('bank_transfer')} className="mt-1 accent-[#8D1528]" />
                  <CreditCard size={19} className="mt-0.5 shrink-0 text-burgundy" /><span><span className="block text-sm font-medium">Bank transfer · payment pending</span><span className="mt-1 block text-xs leading-relaxed text-muted">No account details are fabricated. The store owner must supply verified instructions after reviewing the order.</span></span>
                </label>
              </div>
            </section>
          </div>

          <aside className="h-fit rounded-2xl border border-line bg-white p-5 shadow-card lg:sticky lg:top-28 sm:p-6" aria-labelledby="checkout-summary-title">
            <p className="eyebrow">Your order</p><h2 id="checkout-summary-title" className="mt-1 font-display text-3xl">Order summary</h2>
            <ul className="mt-5 max-h-[360px] divide-y divide-line overflow-auto pr-1">
              {lines.map((line) => (
                <li key={line.id} className="flex gap-3 py-3 first:pt-0">
                  <div className="mini-necklace-wrap h-16 w-16 shrink-0 overflow-hidden rounded-lg border border-line">{line.type === 'product' ? <img src={line.image} alt="" className="h-full w-full object-cover" /> : <MiniNecklaceFromCart line={line} className="h-full w-full" />}</div>
                  <div className="min-w-0 flex-1"><p className="text-xs font-medium leading-snug">{line.name}</p><p className="mt-1 text-[10px] text-muted">{line.type === 'product' ? `Quantity ${line.quantity}` : `Chain + ${line.positions.length} charms`}</p><p className="mt-1 text-xs font-medium text-burgundy">{formatPKR(lineTotal(line))}</p></div>
                </li>
              ))}
            </ul>
            <dl className="mt-5 space-y-3 border-t border-line pt-5 text-sm">
              <div className="flex justify-between"><dt className="text-muted">Subtotal</dt><dd>{formatPKR(subtotal)}</dd></div>
              <div className="flex justify-between"><dt className="text-muted">Shipping</dt><dd>{shipping === 0 ? 'Complimentary' : formatPKR(shipping)}</dd></div>
              <div className="flex justify-between"><dt className="text-muted">Configured tax</dt><dd>{formatPKR(tax)}</dd></div>
              <div className="flex items-end justify-between border-t border-line pt-4"><dt className="font-medium">Total</dt><dd className="font-display text-3xl font-semibold text-burgundy">{formatPKR(total)}</dd></div>
            </dl>
            <label className="mt-5 flex items-start gap-2.5 text-[10px] leading-relaxed text-muted">
              <input type="checkbox" checked={terms} onChange={(e) => { setTerms(e.target.checked); setErrors((current) => ({ ...current, terms: undefined })) }} aria-invalid={Boolean(errors.terms)} className="mt-0.5 accent-[#8D1528]" />
              <span>I understand this is a demo store and agree to the <Link to="/terms" className="text-burgundy underline">demo terms</Link> and <Link to="/privacy" className="text-burgundy underline">privacy notice</Link>.</span>
            </label>
            {errors.terms && <p className="mt-1 text-xs text-burgundy">{errors.terms}</p>}
            <button disabled={busy} className="btn-primary mt-5 w-full">{busy ? 'Recording order…' : <><Check size={16} /> Place demo order</>}</button>
            <p className="mt-3 text-center text-[9px] leading-relaxed text-muted">No payment success will be claimed. Payment remains unpaid or pending.</p>
          </aside>
        </div>
      </form>
    </>
  )
}
