import { Link } from 'react-router-dom'
import { HelpCircle } from 'lucide-react'
import { usePageTitle } from '../lib/hooks'

const faqs = [
  ['How does the necklace builder work?', 'Tap a charm to place it automatically, or drag it from the catalogue onto the chain. Drag an existing charm to move it. Quantity, Undo, Redo, Clear and Zoom controls update the same saved design state.'],
  ['Will my exact arrangement reach checkout?', 'Yes. The bag stores every charm instance, product identifier and normalised position. The server saves a configuration snapshot with the order.'],
  ['Are these products and specifications real inventory?', 'No. This development build uses original demo illustrations, demo stock and illustrative specification labels. The merchant must replace or verify every listing before launch.'],
  ['Which currency is used?', 'The demo catalogue is configured in Pakistani rupees (PKR), displayed as Rs. Server calculations use whole PKR integers to avoid floating-point errors.'],
  ['Can I pay online?', 'Not in this demo. No payment gateway credentials were supplied. Checkout records cash-on-delivery or bank-transfer-pending orders and explicitly reports that no online payment was processed.'],
  ['Does the builder work on a phone?', 'Yes. It uses Pointer Events for touch, stylus and mouse input, and the catalogue uses a compact two-column layout on narrow screens.'],
  ['Can I remove or duplicate a charm?', 'Use the minus and plus controls on its catalogue card or selected-charm card. Select a charm on the canvas and press Delete, or use its visible remove control.'],
  ['How do I track an order?', 'Open Track Order and enter the order number plus the email address or phone used at checkout. Both are required to protect customer details.'],
]

export default function FaqPage() {
  usePageTitle('Frequently Asked Questions')
  return (
    <><section className="border-b border-line bg-petal/45"><div className="mx-auto max-w-3xl px-5 py-14 text-center sm:px-6"><HelpCircle className="mx-auto text-burgundy" size={27}/><p className="eyebrow mt-4">A little clarity</p><h1 className="display-xl mt-2">Frequently asked</h1><p className="mt-4 text-sm text-muted">Transparent answers about this demo store and custom necklace experience.</p></div></section><section className="mx-auto max-w-3xl px-5 py-12 sm:px-6 lg:py-16"><div className="divide-y divide-line rounded-2xl border border-line bg-white px-5 sm:px-7">{faqs.map(([question, answer], index) => <details key={question} className="group py-5" open={index === 0}><summary className="flex cursor-pointer list-none items-center justify-between gap-4 font-display text-xl font-semibold"><span>{question}</span><span className="text-burgundy transition-transform group-open:rotate-45">＋</span></summary><p className="mt-3 pr-8 text-sm leading-7 text-muted">{answer}</p></details>)}</div><div className="mt-8 rounded-2xl bg-blush/60 p-6 text-center"><h2 className="font-display text-2xl">Still curious?</h2><p className="mt-2 text-sm text-muted">Send a note and the configured store team can help.</p><Link to="/contact" className="btn-primary mt-5">Contact us</Link></div></section></>
  )
}
