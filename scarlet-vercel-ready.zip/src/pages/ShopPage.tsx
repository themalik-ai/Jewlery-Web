import { useCallback, useEffect, useRef, useState } from 'react'
import { useSearchParams } from 'react-router-dom'
import { ArrowDown, Sparkles } from 'lucide-react'
import { api } from '../lib/api'
import type { Category, Product } from '../lib/types'
import { usePageTitle } from '../lib/hooks'
import { ProductFilters, type FilterValue } from '../components/products/ProductFilters'
import { ProductGrid } from '../components/products/ProductGrid'

const PAGE_SIZE = 12

export default function ShopPage() {
  usePageTitle('Shop Charms', 'Browse the SCARLET demo charm catalogue in Pakistani rupees.')
  const [searchParams, setSearchParams] = useSearchParams()
  const initial = useRef(true)
  const [filters, setFilters] = useState<FilterValue>({
    search: searchParams.get('search') || '',
    category: searchParams.get('category') || '',
    sort: searchParams.get('sort') || 'featured',
  })
  const [products, setProducts] = useState<Product[]>([])
  const [categories, setCategories] = useState<Category[]>([])
  const [total, setTotal] = useState(0)
  const [loading, setLoading] = useState(true)
  const [loadingMore, setLoadingMore] = useState(false)
  const [error, setError] = useState<string | null>(null)

  const fetchProducts = useCallback(async (offset: number, append = false) => {
    append ? setLoadingMore(true) : setLoading(true)
    setError(null)
    try {
      const data = await api.products({
        search: filters.search,
        category: filters.category,
        sort: filters.sort,
        limit: String(PAGE_SIZE),
        offset: String(offset),
      })
      setProducts((current) => append ? [...current, ...data.products] : data.products)
      setCategories(data.categories)
      setTotal(data.total)
    } catch (reason) {
      setError(reason instanceof Error ? reason.message : 'The catalogue could not be loaded.')
    } finally {
      setLoading(false)
      setLoadingMore(false)
    }
  }, [filters])

  useEffect(() => {
    const timeout = window.setTimeout(() => {
      void fetchProducts(0)
      const params: Record<string, string> = {}
      if (filters.search) params.search = filters.search
      if (filters.category) params.category = filters.category
      if (filters.sort && filters.sort !== 'featured') params.sort = filters.sort
      setSearchParams(params, { replace: !initial.current })
      initial.current = false
    }, 180)
    return () => window.clearTimeout(timeout)
  }, [fetchProducts, filters.search, filters.category, filters.sort, setSearchParams])

  useEffect(() => {
    if (searchParams.get('focus') === 'search') window.setTimeout(() => document.querySelector<HTMLInputElement>('[data-product-search]')?.focus(), 250)
  }, [searchParams])

  return (
    <>
      <section className="border-b border-line bg-petal/45">
        <div className="mx-auto max-w-7xl px-5 py-12 text-center sm:px-6 lg:px-8 lg:py-16">
          <p className="eyebrow">The demo charm case</p>
          <h1 className="display-xl mt-3">Small treasures,<br className="sm:hidden" /> <span className="italic text-burgundy">big meaning.</span></h1>
          <p className="mx-auto mt-4 max-w-2xl text-sm leading-relaxed text-muted">Explore playful symbols, initials, crystals and keepsakes. Product imagery and specifications are original demo content awaiting verified inventory.</p>
        </div>
      </section>

      <section className="mx-auto max-w-7xl px-5 py-10 sm:px-6 lg:px-8 lg:py-14">
        <div className="mb-7 flex flex-col gap-5">
          <div className="flex items-end justify-between gap-4">
            <div><p className="eyebrow">Browse & discover</p><h2 className="mt-1 font-display text-3xl">All charms</h2></div>
            <p className="text-[10px] uppercase tracking-[0.14em] text-muted" aria-live="polite">{loading ? 'Opening the case…' : `${total} ${total === 1 ? 'piece' : 'pieces'}`}</p>
          </div>
          <ProductFilters value={filters} onChange={setFilters} categories={categories} />
        </div>

        <ProductGrid products={products} loading={loading} error={error} mode="shop" />
        {!loading && !error && products.length < total && (
          <div className="mt-10 text-center">
            <button onClick={() => void fetchProducts(products.length, true)} disabled={loadingMore} className="btn-outline">
              {loadingMore ? 'Opening more…' : <>Load more charms <ArrowDown size={14} /></>}
            </button>
            <p className="mt-3 text-[10px] text-muted">Showing {products.length} of {total}</p>
          </div>
        )}
      </section>

      <section className="mx-auto max-w-7xl px-5 pb-4 sm:px-6 lg:px-8">
        <div className="flex flex-col items-center justify-between gap-5 rounded-2xl border border-rose/45 bg-blush/55 px-6 py-8 text-center sm:flex-row sm:text-left">
          <div className="flex items-center gap-4"><span className="grid h-12 w-12 place-items-center rounded-full bg-white text-burgundy"><Sparkles size={20} /></span><div><h2 className="font-display text-2xl">Want to see them together?</h2><p className="mt-1 text-xs text-muted">Open the studio and arrange your favourites on the chain.</p></div></div>
          <a href="/builder" className="btn-primary shrink-0">Design a necklace</a>
        </div>
      </section>
    </>
  )
}
