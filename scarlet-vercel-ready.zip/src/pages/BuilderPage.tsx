import { useEffect, useState } from 'react'
import { AlertCircle } from 'lucide-react'
import { api } from '../lib/api'
import type { Category, Product } from '../lib/types'
import { usePageTitle } from '../lib/hooks'
import { NecklaceBuilder } from '../components/builder/NecklaceBuilder'

export default function BuilderPage() {
  usePageTitle('Design Your Necklace', 'Drag, arrange and customise your own charm necklace with the interactive SCARLET builder.')
  const [products, setProducts] = useState<Product[]>([])
  const [categories, setCategories] = useState<Category[]>([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)

  useEffect(() => {
    let active = true
    api.products({ limit: '100', sort: 'featured' })
      .then((data) => { if (active) { setProducts(data.products); setCategories(data.categories); setLoading(false) } })
      .catch((reason) => { if (active) { setError(reason instanceof Error ? reason.message : 'The builder could not load.'); setLoading(false) } })
    return () => { active = false }
  }, [])

  return (
    <>
      <section className="border-b border-line bg-gradient-to-b from-blush/45 to-ivory">
        <div className="mx-auto max-w-7xl px-5 py-10 text-center sm:px-6 lg:px-8 lg:py-14">
          <p className="eyebrow">The necklace studio</p>
          <h1 className="display-xl mt-3">Design something<br className="sm:hidden" /> <span className="italic text-burgundy">only you</span> could make.</h1>
          <p className="mx-auto mt-4 max-w-2xl text-sm leading-relaxed text-muted">Tap a charm or drag it onto the chain. Move every piece, add multiples, undo a change, and keep your exact arrangement through checkout.</p>
        </div>
      </section>
      <div className="mx-auto max-w-7xl px-3 py-8 sm:px-6 lg:px-8 lg:py-12">
        {loading ? (
          <div className="space-y-5" aria-busy="true"><div className="skeleton aspect-[1000/580] w-full rounded-[26px]" /><div className="skeleton h-12 w-full rounded-full" /><div className="grid grid-cols-2 gap-3 sm:grid-cols-4 lg:grid-cols-6">{Array.from({ length: 12 }, (_, index) => <div key={index} className="skeleton aspect-square rounded-xl" />)}</div></div>
        ) : error ? (
          <div className="rounded-2xl border border-rose/50 bg-blush/40 px-6 py-16 text-center" role="alert"><AlertCircle className="mx-auto text-burgundy" /><h2 className="mt-4 font-display text-3xl">The studio did not open</h2><p className="mt-2 text-sm text-muted">{error}</p><button onClick={() => window.location.reload()} className="btn-primary mt-5">Try again</button></div>
        ) : (
          <NecklaceBuilder products={products} categories={categories} />
        )}
      </div>
    </>
  )
}
