import { Link } from 'react-router-dom'
import { FileText, ShieldCheck, Truck, Undo2 } from 'lucide-react'
import { usePageTitle } from '../lib/hooks'

const pages = {
  shipping: {
    title: 'Shipping & delivery', eyebrow: 'Demo policy draft', icon: Truck,
    intro: 'No verified dispatch timelines, carriers or delivery coverage were provided. The statements below describe what the merchant must configure before accepting live orders.',
    sections: [
      ['Delivery methods', 'Standard and express options are enabled in the demo checkout with configurable prices. Their estimated arrival times remain intentionally unspecified until the merchant confirms operations and courier agreements.'],
      ['Shipping charges', 'The administrator can configure standard shipping, express shipping and a standard free-shipping threshold. The server—not the browser—applies those values when recording an order.'],
      ['Order tracking', 'Customers can securely look up order status using both their order number and checkout contact detail. Courier tracking numbers appear only after an authorised administrator adds verified fulfilment data.'],
      ['International delivery', 'No international service is claimed. Define service regions, customs responsibility and applicable charges before offering cross-border delivery.'],
    ],
  },
  returns: {
    title: 'Returns & refunds', eyebrow: 'Demo policy draft', icon: Undo2,
    intro: 'A real returns window, exclusions and refund method were not supplied. This page avoids creating obligations on behalf of an unidentified merchant.',
    sections: [
      ['Before launch', 'The store owner must define a legally appropriate returns period, the condition required for returned jewellery, hygiene considerations and whether customised designs can be returned.'],
      ['Damaged or incorrect items', 'A production policy should explain how quickly customers must report an issue and what photos or order details are needed. Do not ask customers to send sensitive payment information.'],
      ['Refund processing', 'Refunds must follow the actual payment provider or approved offline process. This demo does not issue refunds or claim a processing timeline.'],
      ['Start a request', 'Until verified terms are configured, use the contact form and quote the demo order number. No return is automatically authorised by sending a message.'],
    ],
  },
  privacy: {
    title: 'Privacy policy', eyebrow: 'Demo privacy notice', icon: ShieldCheck,
    intro: 'This is a development implementation, not legal advice. A qualified reviewer should adapt this notice to the operator, hosting region, vendors and applicable law.',
    sections: [
      ['Data collected', 'Checkout stores name, email, phone, address, city, postal code, delivery note, item snapshots and order totals. Contact and newsletter forms store the details submitted. The necklace design and shopping bag also persist in browser storage.'],
      ['Why it is used', 'Data supports catalogue browsing, restoring a design, recording and fulfilling orders, responding to messages, tracking order status and protecting administrative tools.'],
      ['Storage and access', 'This demo uses a local SQLite database and role-protected admin API. A production deployment needs documented hosting, retention periods, encrypted transport, backups, access review and deletion procedures.'],
      ['Payments and sharing', 'No card data is collected and no live payment processor is connected. Production vendors, analytics and marketing tools must be listed accurately before use.'],
      ['Your choices', 'A real operator must provide verified contact details and processes for access, correction or deletion requests as required by applicable law.'],
    ],
  },
  terms: {
    title: 'Terms & conditions', eyebrow: 'Demo terms draft', icon: FileText,
    intro: 'These placeholders explain the demonstration environment. They are not ready to govern real sales and must be replaced with merchant-approved legal terms.',
    sections: [
      ['Demo catalogue', 'Product names, images, stock, composition, finishes and descriptions are illustrative unless explicitly verified by the merchant. No gemstone authenticity, metal purity, warranty or availability claim is made.'],
      ['Pricing and orders', 'Prices are shown in PKR and re-read from the backend when an order is created. A recorded demo order is not proof of online payment or merchant acceptance.'],
      ['Custom necklace designs', 'The saved configuration includes charm identities and positions. Physical production tolerances, chain specifications and assembly rules require confirmation before live fulfilment.'],
      ['Payment status', 'Only cash-on-delivery and bank-transfer-pending demonstration flows are enabled. No payment gateway is connected, no card data is accepted and checkout never claims a processed payment.'],
      ['Liability and governing terms', 'The actual business must supply its legal identity, jurisdiction, consumer-rights terms, limitations and dispute process after professional review.'],
    ],
  },
} as const

export default function PolicyPage({ type }: { type: keyof typeof pages }) {
  const page = pages[type]
  const Icon = page.icon
  usePageTitle(page.title)
  return (
    <><section className="border-b border-line bg-petal/45"><div className="mx-auto max-w-4xl px-5 py-14 text-center sm:px-6"><Icon className="mx-auto text-burgundy" size={27}/><p className="eyebrow mt-4">{page.eyebrow}</p><h1 className="display-xl mt-2">{page.title}</h1><p className="mx-auto mt-4 max-w-2xl text-sm leading-7 text-muted">{page.intro}</p><span className="mt-5 inline-flex rounded-full border border-burgundy/25 bg-white px-3 py-1 text-[9px] uppercase tracking-[.14em] text-burgundy">Not production legal copy</span></div></section><section className="mx-auto max-w-4xl px-5 py-12 sm:px-6 lg:py-16"><div className="grid gap-4">{page.sections.map(([title, text], index) => <article key={title} className="grid gap-3 rounded-2xl border border-line bg-white p-5 sm:grid-cols-[48px_1fr] sm:p-6"><span className="font-display text-2xl italic text-rose-deep">0{index+1}</span><div><h2 className="font-display text-2xl font-semibold">{title}</h2><p className="mt-2 text-sm leading-7 text-muted">{text}</p></div></article>)}</div><div className="mt-8 flex flex-col items-center justify-between gap-4 rounded-2xl bg-blush/60 p-6 text-center sm:flex-row sm:text-left"><div><h2 className="font-display text-2xl">Need clarification?</h2><p className="mt-1 text-sm text-muted">Ask before placing or fulfilling a real order.</p></div><Link to="/contact" className="btn-primary shrink-0">Contact the store</Link></div></section></>
  )
}
