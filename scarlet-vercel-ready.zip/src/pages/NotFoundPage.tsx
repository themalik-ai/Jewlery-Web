import { Link } from 'react-router-dom'
import { Gem } from 'lucide-react'
import { usePageTitle } from '../lib/hooks'

export default function NotFoundPage() {
  usePageTitle('Page Not Found')
  return <div className="mx-auto max-w-xl px-5 py-24 text-center"><Gem className="mx-auto text-burgundy" size={32} strokeWidth={1.4} /><p className="eyebrow mt-5">404</p><h1 className="mt-2 font-display text-5xl">A missing little gem.</h1><p className="mt-4 text-sm text-muted">The page you’re looking for is not in this charm case.</p><div className="mt-7 flex justify-center gap-3"><Link to="/" className="btn-outline">Go home</Link><Link to="/builder" className="btn-primary">Start designing</Link></div></div>
}
