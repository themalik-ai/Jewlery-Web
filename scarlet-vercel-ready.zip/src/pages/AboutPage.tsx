import { Link } from 'react-router-dom'
import { Gem, Heart, Sparkles } from 'lucide-react'
import { usePageTitle } from '../lib/hooks'

export default function AboutPage() {
  usePageTitle('About Us')
  return (
    <>
      <section className="hero-shell"><div className="mx-auto grid max-w-6xl items-center gap-10 px-5 py-16 sm:px-6 lg:grid-cols-2 lg:px-8 lg:py-24"><div><p className="eyebrow">About this atelier</p><h1 className="display-xl mt-3">Jewellery for the stories <span className="italic text-burgundy">you choose.</span></h1><p className="mt-6 text-sm leading-7 text-muted">SCARLET is the configurable placeholder identity for this demonstration storefront. Because no verified brand history was supplied, this page does not invent a founder, founding date or business credentials.</p><Link to="/builder" className="btn-primary mt-7">Make your necklace</Link></div><div className="arch-frame grid aspect-[.9] place-items-center border border-rose/45 bg-blush/60"><div className="text-center"><span className="mx-auto grid h-24 w-24 place-items-center rounded-full border border-gold/40 bg-white text-burgundy"><Gem size={38} strokeWidth={1.2} /></span><p className="mt-6 font-display text-3xl italic text-burgundy">Made meaningful by you.</p></div></div></div></section>
      <section className="mx-auto max-w-6xl px-5 py-16 sm:px-6 lg:px-8 lg:py-20"><div className="text-center"><p className="eyebrow">Design principles</p><h2 className="section-title mt-2">What this demo stands for</h2></div><div className="mt-10 grid gap-4 md:grid-cols-3">{[[Heart,'Personal, never prescribed','The builder gives each customer control of the arrangement and meaning.'],[Sparkles,'Delightfully tactile','Touch, pointer and keyboard interactions make designing feel direct and playful.'],[Gem,'Honest by default','Demo data, unverified specifications and offline payment status are labelled clearly.']].map(([Icon,title,text]) => { const C=Icon as typeof Heart; return <article key={String(title)} className="rounded-2xl border border-line bg-white p-6 text-center"><span className="mx-auto grid h-11 w-11 place-items-center rounded-full bg-blush text-burgundy"><C size={19}/></span><h3 className="mt-4 font-display text-2xl">{String(title)}</h3><p className="mt-2 text-sm leading-relaxed text-muted">{String(text)}</p></article>})}</div></section>
    </>
  )
}
