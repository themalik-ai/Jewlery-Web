import { FormEvent, useState } from 'react'
import { useSearchParams } from 'react-router-dom'
import { Clock, Package, Search, Truck } from 'lucide-react'
import { api } from '../lib/api'
import type { Order } from '../lib/types'
import { formatPKR } from '../config/store'
import { usePageTitle } from '../lib/hooks'

const statuses = ['pending', 'confirmed', 'in_production', 'shipped', 'delivered']
const labels: Record<string, string> = { pending: 'Pending review', confirmed: 'Confirmed', in_production: 'In production', shipped: 'Shipped', delivered: 'Delivered', cancelled: 'Cancelled' }

export default function TrackOrderPage() {
  usePageTitle('Track Order')
  const [searchParams] = useSearchParams()
  const [orderNumber, setOrderNumber] = useState(searchParams.get('order') || '')
  const [contact, setContact] = useState('')
  const [order, setOrder] = useState<Order | null>(null)
  const [error, setError] = useState('')
  const [busy, setBusy] = useState(false)

  async function track(event: FormEvent) {
    event.preventDefault()
    setBusy(true); setError(''); setOrder(null)
    try { const data = await api.trackOrder(orderNumber.trim().toUpperCase(), contact.trim()); setOrder(data.order) }
    catch (reason) { setError(reason instanceof Error ? reason.message : 'Order could not be found.') }
    finally { setBusy(false) }
  }

  const current = order ? statuses.indexOf(order.status) : -1
  return (
    <>
      <section className="border-b border-line bg-petal/45"><div className="mx-auto max-w-3xl px-5 py-12 text-center sm:px-6 lg:py-16"><Package className="mx-auto text-burgundy" size={25} /><p className="eyebrow mt-4">From atelier to you</p><h1 className="display-xl mt-2">Track your order</h1><p className="mx-auto mt-3 max-w-xl text-sm leading-relaxed text-muted">Enter the order number and the same email or phone used at checkout. Both details are required to protect your information.</p></div></section>
      <section className="mx-auto max-w-3xl px-5 py-10 sm:px-6 lg:py-14">
        <form onSubmit={track} className="rounded-2xl border border-line bg-white p-5 shadow-card sm:p-7">
          <div className="grid gap-4 sm:grid-cols-2"><label><span className="label">Order number</span><input value={orderNumber} onChange={(e) => setOrderNumber(e.target.value.toUpperCase())} className="input" placeholder="SC-20261020-AB12" required /></label><label><span className="label">Email or phone</span><input value={contact} onChange={(e) => setContact(e.target.value)} className="input" placeholder="Used at checkout" required /></label></div>
          {error && <p className="mt-3 text-sm text-burgundy" role="alert">{error}</p>}
          <button disabled={busy} className="btn-primary mt-5 w-full sm:w-auto"><Search size={15} /> {busy ? 'Looking…' : 'Find my order'}</button>
        </form>

        {order && (
          <div className="mt-7 animate-floatIn rounded-2xl border border-line bg-cream/50 p-5 sm:p-7">
            <div className="flex flex-col gap-3 sm:flex-row sm:items-end sm:justify-between"><div><p className="eyebrow">{order.order_number}</p><h2 className="mt-1 font-display text-3xl">{labels[order.status]}</h2><p className="mt-1 text-xs text-muted">Placed {new Date(`${order.created_at}Z`).toLocaleString()}</p></div><div className="sm:text-right"><p className="text-[9px] uppercase tracking-[.14em] text-muted">Order total</p><p className="font-display text-2xl font-semibold text-burgundy">{formatPKR(order.total_pkr)}</p></div></div>
            {order.status === 'cancelled' ? <p className="mt-6 rounded-xl bg-blush p-4 text-sm text-burgundy">This order is marked cancelled. Contact the store if you need help.</p> : (
              <div className="mt-8 grid grid-cols-5 gap-1">
                {statuses.map((status, index) => <div key={status} className="text-center"><div className={`mx-auto grid h-8 w-8 place-items-center rounded-full border ${index <= current ? 'border-burgundy bg-burgundy text-white' : 'border-line bg-white text-muted'}`}>{index < current ? '✓' : index + 1}</div><div className={`mx-auto my-2 h-0.5 w-full ${index <= current ? 'bg-burgundy' : 'bg-line'}`} /><p className="text-[7px] uppercase tracking-[.08em] text-muted sm:text-[9px]">{labels[status]}</p></div>)}
              </div>
            )}
            <div className="mt-7 flex gap-3 rounded-xl border border-line bg-white p-4 text-xs leading-relaxed text-muted"><Truck size={18} className="shrink-0 text-burgundy" /><p>Delivery estimates and tracking numbers appear only after the merchant enters verified fulfilment details. This demo does not invent them.</p></div>
          </div>
        )}
      </section>
    </>
  )
}
