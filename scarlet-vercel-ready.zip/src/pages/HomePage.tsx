import { useEffect, useState } from 'react'
import { Link } from 'react-router-dom'
import { ArrowRight, Gem, Hand, Heart, ShieldCheck, Sparkles } from 'lucide-react'
import { api } from '../lib/api'
import type { Product } from '../lib/types'
import { usePageTitle } from '../lib/hooks'
import { ProductGrid } from '../components/products/ProductGrid'
import { MiniNecklace } from '../components/builder/MiniNecklace'

const collectionMeta = [
  { slug: 'cherry-charms', title: 'Cherry on top', copy: 'Playful details with a nostalgic glow.', color: 'bg-[#F9E4E7]' },
  { slug: 'moon-star-charms', title: 'Written in the stars', copy: 'Celestial keepsakes for dreamers.', color: 'bg-[#E9EAF2]' },
  { slug: 'heart-charms', title: 'Love letters', copy: 'Small symbols, close to your heart.', color: 'bg-[#F8E8EE]' },
]

export default function HomePage() {
  usePageTitle('', 'Design a custom charm necklace with SCARLET, a configurable demo jewellery storefront.')
  const [products, setProducts] = useState<Product[]>([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)

  useEffect(() => {
    let active = true
    api.products({ limit: '100', sort: 'featured' })
      .then((data) => { if (active) { setProducts(data.products); setLoading(false) } })
      .catch((reason) => { if (active) { setError(reason instanceof Error ? reason.message : 'Catalogue unavailable.'); setLoading(false) } })
    return () => { active = false }
  }, [])

  const featured = products.filter((product) => product.is_featured).slice(0, 8)
  const heroProducts = featured.slice(0, 3)
  const heroPositions = heroProducts.map((product, index) => ({ productId: product.id, t: [0.38, 0.5, 0.62][index] }))

  return (
    <>
      <section className="hero-shell relative overflow-hidden">
        <div className="pointer-events-none absolute -left-28 top-24 h-72 w-72 rounded-full border border-rose/25" />
        <div className="pointer-events-none absolute -left-16 top-36 h-52 w-52 rounded-full border border-gold/15" />
        <div className="mx-auto grid min-h-[630px] max-w-7xl items-center gap-8 px-5 py-14 sm:px-6 lg:grid-cols-[0.9fr_1.1fr] lg:px-8 lg:py-16">
          <div className="relative z-10 max-w-xl lg:pl-5">
            <p className="eyebrow">The charm atelier · demo collection</p>
            <h1 className="display-xl mt-5">Tell your story,<br /><span className="italic text-burgundy">one charm</span> at a time.</h1>
            <p className="mt-6 max-w-lg text-sm leading-7 text-muted sm:text-base">Pick the pieces that feel like you, place them on a delicate gold chain, and make a necklace that is entirely yours.</p>
            <div className="mt-8 flex flex-col gap-3 sm:flex-row">
              <Link to="/builder" className="btn-primary">Design your necklace <ArrowRight size={15} /></Link>
              <Link to="/shop" className="btn-outline">Shop the charm case</Link>
            </div>
            <div className="mt-8 flex flex-wrap gap-x-6 gap-y-3 text-[10px] uppercase tracking-[0.13em] text-muted">
              <span className="inline-flex items-center gap-2"><Hand size={14} className="text-gold" /> Touch-friendly designer</span>
              <span className="inline-flex items-center gap-2"><ShieldCheck size={14} className="text-gold" /> Server-checked prices</span>
            </div>
          </div>

          <div className="relative mx-auto w-full max-w-[690px] lg:ml-auto">
            <span className="absolute -right-3 top-14 z-10 rounded-full bg-burgundy px-4 py-2 text-[9px] uppercase tracking-[0.15em] text-white shadow-soft sm:right-3">Made by you</span>
            <div className="arch-frame relative aspect-[1.08] overflow-hidden border border-rose/50 bg-cream shadow-soft sm:aspect-[1.22]">
              <div className="absolute inset-x-8 top-5 text-center sm:top-8">
                <p className="font-display text-2xl italic text-burgundy sm:text-3xl">A necklace as individual as you.</p>
              </div>
              {heroProducts.length > 0 ? (
                <MiniNecklace positions={heroPositions} products={heroProducts} className="absolute inset-x-[-15%] bottom-[-5%] h-[88%] w-[130%]" />
              ) : (
                <div className="skeleton absolute inset-12 rounded-t-full" />
              )}
              <div className="absolute bottom-6 left-1/2 flex -translate-x-1/2 items-center gap-2 rounded-full border border-white/70 bg-white/75 px-4 py-2 text-[9px] uppercase tracking-[0.14em] text-burgundy backdrop-blur">
                <Sparkles size={12} /> Drag · arrange · adore
              </div>
            </div>
            <div className="absolute -bottom-5 -left-3 hidden w-36 rotate-[-4deg] rounded-xl border border-line bg-white p-2 shadow-soft sm:block">
              {heroProducts[0] && <img src={heroProducts[0].image_url} alt="" className="aspect-square w-full rounded-lg object-cover" />}
              <p className="mt-1 text-center text-[8px] uppercase tracking-wide text-muted">Pick your charm</p>
            </div>
          </div>
        </div>
      </section>

      <div className="overflow-hidden border-y border-line bg-white py-3.5" aria-hidden="true">
        <div className="marquee-track text-[9px] uppercase tracking-[0.28em] text-muted">
          {Array.from({ length: 2 }, (_, set) => (
            <div key={set} className="flex gap-12">
              <span>Choose your charms</span><span className="text-gold">✦</span><span>Build your story</span><span className="text-gold">✦</span><span>Made by you</span><span className="text-gold">✦</span><span>Designed to treasure</span><span className="text-gold">✦</span>
            </div>
          ))}
        </div>
      </div>

      <section className="mx-auto max-w-7xl px-5 py-16 sm:px-6 lg:px-8 lg:py-20" aria-labelledby="collections-title">
        <div className="mb-8 flex items-end justify-between gap-5">
          <div><p className="eyebrow">Find your mood</p><h2 id="collections-title" className="section-title mt-2">Little worlds to explore</h2></div>
          <Link to="/shop" className="hidden items-center gap-2 text-[10px] uppercase tracking-[0.15em] text-burgundy sm:flex">View all <ArrowRight size={14} /></Link>
        </div>
        <div className="grid gap-4 md:grid-cols-3">
          {collectionMeta.map((collection) => {
            const items = products.filter((product) => product.category === collection.slug).slice(0, 3)
            return (
              <Link key={collection.slug} to={`/shop?category=${collection.slug}`} className={`group relative min-h-[320px] overflow-hidden rounded-2xl border border-line p-6 ${collection.color}`}>
                <div className="relative z-10 max-w-[55%]">
                  <p className="eyebrow">Collection</p>
                  <h3 className="mt-2 font-display text-3xl leading-tight">{collection.title}</h3>
                  <p className="mt-2 text-xs leading-relaxed text-muted">{collection.copy}</p>
                  <span className="mt-5 inline-flex h-9 w-9 items-center justify-center rounded-full border border-burgundy/30 text-burgundy transition-all group-hover:bg-burgundy group-hover:text-white"><ArrowRight size={15} /></span>
                </div>
                <div className="absolute -bottom-5 -right-4 h-[80%] w-[62%]">
                  {items.map((item, index) => <img key={item.id} src={item.image_url} alt="" className="absolute aspect-square w-[62%] rounded-full object-cover shadow-card transition-transform duration-300 group-hover:scale-105" style={{ right: `${index * 17}%`, bottom: `${index * 22}px`, transform: `rotate(${(index - 1) * 7}deg)` }} />)}
                </div>
              </Link>
            )
          })}
        </div>
      </section>

      <section className="bg-petal/55 py-16 lg:py-20" aria-labelledby="popular-title">
        <div className="mx-auto max-w-7xl px-5 sm:px-6 lg:px-8">
          <div className="mb-8 text-center"><p className="eyebrow">From the charm case</p><h2 id="popular-title" className="section-title mt-2">The ones everyone reaches for</h2><p className="mx-auto mt-3 max-w-xl text-sm text-muted">Original demo illustrations and illustrative product details. Replace with verified inventory photography before launch.</p></div>
          <ProductGrid products={featured} loading={loading} error={error} mode="shop" />
          <div className="mt-9 text-center"><Link to="/shop" className="btn-outline">Meet every charm <ArrowRight size={14} /></Link></div>
        </div>
      </section>

      <section className="mx-auto max-w-7xl px-5 py-16 sm:px-6 lg:px-8 lg:py-24">
        <div className="grid items-center gap-12 lg:grid-cols-[1.05fr_.95fr]">
          <div className="relative rounded-[28px] border border-rose/45 bg-cream p-5 sm:p-8">
            {products.length > 0 && <MiniNecklace positions={products.slice(3, 8).map((product, index) => ({ productId: product.id, t: [0.3, 0.4, 0.5, 0.6, 0.7][index] }))} products={products} className="aspect-[1000/580] w-full" />}
            <span className="absolute bottom-4 right-4 rounded-full bg-white px-3 py-1.5 text-[8px] uppercase tracking-[0.14em] text-muted shadow-card">Example arrangement</span>
          </div>
          <div>
            <p className="eyebrow">Three lovely steps</p>
            <h2 className="section-title mt-3">From little treasures<br />to <span className="italic text-burgundy">your</span> necklace.</h2>
            <div className="mt-8 space-y-6">
              {[
                ['01', 'Choose what speaks to you', 'Browse flowers, hearts, initials, celestial pieces and tiny talismans.'],
                ['02', 'Place every charm', 'Tap to add or drag directly to the chain. Reorder, duplicate, undo and zoom with ease.'],
                ['03', 'Save your composition', 'Your exact charm identities and positions travel with the necklace into the bag and checkout.'],
              ].map(([number, title, text]) => (
                <div key={number} className="flex gap-5 border-b border-line pb-5 last:border-0">
                  <span className="font-display text-2xl italic text-rose-deep">{number}</span>
                  <div><h3 className="font-display text-xl font-semibold">{title}</h3><p className="mt-1 text-sm leading-relaxed text-muted">{text}</p></div>
                </div>
              ))}
            </div>
            <Link to="/builder" className="btn-primary mt-7">Open the necklace studio <Gem size={15} /></Link>
          </div>
        </div>
      </section>

      <section className="burgundy-band py-16 text-ivory lg:py-20">
        <div className="mx-auto max-w-7xl px-5 sm:px-6 lg:px-8">
          <div className="grid gap-10 lg:grid-cols-[.75fr_1.25fr]">
            <div><p className="eyebrow !text-rose">Review section preview</p><h2 className="mt-3 font-display text-4xl leading-tight">Real words belong to real customers.</h2><p className="mt-4 text-sm leading-relaxed text-ivory/60">No customer endorsements have been invented for this demo. These cards reserve the intended review layout until verified feedback is supplied.</p><Heart className="mt-6 text-gold-light" size={26} strokeWidth={1.3} /></div>
            <div className="grid gap-3 sm:grid-cols-3">
              {[['Verified review pending', 'Customer feedback will appear here after consent and verification.'], ['Photo review pending', 'A real custom necklace story can be featured in this space.'], ['Store launch pending', 'Ratings remain hidden until genuine orders generate feedback.']].map(([title, text]) => (
                <article key={title} className="rounded-2xl border border-ivory/15 bg-ivory/[.06] p-5">
                  <p className="text-gold-light">☆ ☆ ☆ ☆ ☆</p><h3 className="mt-5 font-display text-xl">{title}</h3><p className="mt-2 text-xs leading-relaxed text-ivory/55">{text}</p><span className="mt-5 inline-flex rounded-full border border-rose/35 px-2.5 py-1 text-[8px] uppercase tracking-[.14em] text-rose">Placeholder · not a review</span>
                </article>
              ))}
            </div>
          </div>
        </div>
      </section>
    </>
  )
}
