import { useEffect, useState } from 'react'
import { Link, useLocation, useParams } from 'react-router-dom'
import { CheckCircle2, Clock, Copy, PackageCheck, Printer } from 'lucide-react'
import type { Order } from '../lib/types'
import { formatPKR } from '../config/store'
import { usePageTitle } from '../lib/hooks'
import { useUiStore } from '../store/uiStore'

interface ConfirmationData {
  order: Order
  payment: { mode: string; status: string; message: string }
}

export default function OrderConfirmationPage() {
  const { orderNumber = '' } = useParams()
  const location = useLocation()
  const addToast = useUiStore((state) => state.addToast)
  const [data, setData] = useState<ConfirmationData | null>(() => {
    const state = location.state as ConfirmationData | null
    if (state?.order) return state
    try {
      const saved = sessionStorage.getItem(`scarlet-order-${orderNumber}`)
      return saved ? JSON.parse(saved) : null
    } catch { return null }
  })
  usePageTitle('Order Received')

  useEffect(() => {
    if (!data) {
      try {
        const saved = sessionStorage.getItem(`scarlet-order-${orderNumber}`)
        if (saved) setData(JSON.parse(saved))
      } catch { /* ignore */ }
    }
  }, [data, orderNumber])

  if (!data) return (
    <div className="mx-auto max-w-xl px-5 py-24 text-center"><Clock className="mx-auto text-burgundy" size={32} /><h1 className="mt-4 font-display text-4xl">Order details are private</h1><p className="mt-3 text-sm leading-relaxed text-muted">For privacy, this confirmation is available only in the browser session that placed the order. Use order tracking with your contact detail to retrieve its status.</p><Link to="/track-order" className="btn-primary mt-6">Track {orderNumber || 'an order'}</Link></div>
  )

  const { order, payment } = data
  return (
    <section className="mx-auto max-w-4xl px-5 py-12 sm:px-6 lg:px-8 lg:py-16">
      <div className="text-center">
        <span className="mx-auto grid h-16 w-16 place-items-center rounded-full bg-[#EAF4EB] text-[#4F805D]"><CheckCircle2 size={30} /></span>
        <p className="eyebrow mt-5">Order safely recorded</p>
        <h1 className="mt-2 font-display text-4xl sm:text-5xl">Thank you, {order.customer_name.split(' ')[0]}.</h1>
        <p className="mx-auto mt-3 max-w-xl text-sm leading-relaxed text-muted">Your demo order is in the atelier queue. No online payment was processed and no payment-success claim is being made.</p>
      </div>

      <div className="mt-9 overflow-hidden rounded-2xl border border-line bg-white shadow-card">
        <div className="flex flex-col gap-4 bg-blush/45 px-5 py-5 sm:flex-row sm:items-center sm:justify-between sm:px-7">
          <div><p className="text-[9px] uppercase tracking-[0.14em] text-muted">Order number</p><p className="mt-1 font-display text-2xl font-semibold text-burgundy">{order.order_number}</p></div>
          <div className="flex gap-2">
            <button onClick={async () => { await navigator.clipboard.writeText(order.order_number); addToast('Order number copied.') }} className="chip"><Copy size={12} /> Copy</button>
            <button onClick={() => window.print()} className="chip"><Printer size={12} /> Print</button>
          </div>
        </div>
        <div className="grid gap-8 p-5 sm:grid-cols-2 sm:p-7">
          <div>
            <h2 className="font-display text-2xl">What happens next</h2>
            <ol className="mt-5 space-y-4">
              {[
                ['Recorded', 'The backend saved your item and necklace configuration snapshots.'],
                ['Merchant review', 'A real store team would verify stock, payment method and delivery details.'],
                ['Status update', 'Track this order using the number above and your checkout email or phone.'],
              ].map(([title, text], index) => (
                <li key={title} className="flex gap-3"><span className="grid h-6 w-6 shrink-0 place-items-center rounded-full bg-burgundy text-[9px] text-white">{index + 1}</span><div><p className="text-sm font-medium">{title}</p><p className="mt-1 text-xs leading-relaxed text-muted">{text}</p></div></li>
              ))}
            </ol>
          </div>
          <div className="rounded-xl border border-line bg-cream/50 p-4">
            <div className="flex items-center gap-2 text-burgundy"><PackageCheck size={18} /><h2 className="text-sm font-medium">Order summary</h2></div>
            <ul className="mt-4 space-y-3">{order.items?.map((item) => <li key={item.id} className="flex justify-between gap-3 text-xs"><span className="text-muted">{item.quantity} × {item.name}</span><span className="font-medium">{formatPKR(item.unit_price_pkr * item.quantity)}</span></li>)}</ul>
            <dl className="mt-4 space-y-2 border-t border-line pt-4 text-xs"><div className="flex justify-between"><dt className="text-muted">Subtotal</dt><dd>{formatPKR(order.subtotal_pkr)}</dd></div><div className="flex justify-between"><dt className="text-muted">Shipping</dt><dd>{formatPKR(order.shipping_pkr)}</dd></div><div className="flex justify-between"><dt className="text-muted">Tax</dt><dd>{formatPKR(order.tax_pkr)}</dd></div><div className="flex justify-between pt-2 text-base font-medium"><dt>Total</dt><dd className="text-burgundy">{formatPKR(order.total_pkr)}</dd></div></dl>
          </div>
        </div>
        <div className="border-t border-line px-5 py-4 sm:px-7"><div className="flex gap-2 rounded-xl border border-gold/30 bg-cream p-3 text-xs leading-relaxed text-muted"><Clock size={16} className="mt-0.5 shrink-0 text-gold" /><p><strong className="text-ink">Payment status: {order.payment_status}.</strong> {payment.message}</p></div></div>
      </div>

      <div className="mt-7 flex flex-col justify-center gap-3 sm:flex-row"><Link to={`/track-order?order=${order.order_number}`} className="btn-primary">Track this order</Link><Link to="/shop" className="btn-outline">Continue exploring</Link></div>
    </section>
  )
}
