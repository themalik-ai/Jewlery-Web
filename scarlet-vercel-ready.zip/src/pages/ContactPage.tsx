import { FormEvent, useState } from 'react'
import { Mail, MapPin, MessageCircle, Phone, Send } from 'lucide-react'
import { api } from '../lib/api'
import { usePageTitle } from '../lib/hooks'
import { useSettingsStore } from '../store/settingsStore'
import { useUiStore } from '../store/uiStore'

export default function ContactPage() {
  usePageTitle('Contact Us')
  const settings = useSettingsStore((state) => state.settings)
  const addToast = useUiStore((state) => state.addToast)
  const [form, setForm] = useState({ name: '', email: '', message: '' })
  const [busy, setBusy] = useState(false)
  const [error, setError] = useState('')

  async function submit(event: FormEvent) {
    event.preventDefault(); setBusy(true); setError('')
    try { await api.contact(form); setForm({ name: '', email: '', message: '' }); addToast('Your message was saved for the demo store.') }
    catch (reason) { setError(reason instanceof Error ? reason.message : 'Message could not be sent.') }
    finally { setBusy(false) }
  }

  return (
    <>
      <section className="border-b border-line bg-petal/45"><div className="mx-auto max-w-5xl px-5 py-14 text-center sm:px-6 lg:py-18"><MessageCircle className="mx-auto text-burgundy" size={26} /><p className="eyebrow mt-4">We’re listening</p><h1 className="display-xl mt-2">Talk to the atelier</h1><p className="mx-auto mt-4 max-w-xl text-sm leading-relaxed text-muted">Questions about a charm, your design, or a demo order? Send a note below.</p></div></section>
      <section className="mx-auto grid max-w-5xl gap-8 px-5 py-12 sm:px-6 lg:grid-cols-[.75fr_1.25fr] lg:py-16">
        <aside className="rounded-2xl bg-burgundy p-6 text-ivory sm:p-8"><p className="eyebrow !text-rose">Demo store details</p><h2 className="mt-2 font-display text-3xl">Contact information</h2><p className="mt-3 text-xs leading-relaxed text-ivory/60">These details are placeholders, not a verified business identity. Replace them in Admin → Settings before launch.</p><div className="mt-8 space-y-5 text-sm"><div className="flex gap-3"><Mail size={17} className="text-gold-light" /><span>{settings.store_email}</span></div><div className="flex gap-3"><Phone size={17} className="text-gold-light" /><span>{settings.store_phone}</span></div><div className="flex gap-3"><MapPin size={17} className="text-gold-light" /><span>{settings.store_address}</span></div></div><div className="mt-8 rounded-xl border border-ivory/15 bg-ivory/[.06] p-4 text-xs leading-relaxed text-ivory/60">Messages submitted here are saved to the local demo backend. Connect an approved support workflow and retention policy for production.</div></aside>
        <form onSubmit={submit} className="rounded-2xl border border-line bg-white p-6 shadow-card sm:p-8"><p className="eyebrow">Send a message</p><h2 className="mt-2 font-display text-3xl">How can we help?</h2><div className="mt-6 grid gap-4 sm:grid-cols-2"><label><span className="label">Your name</span><input className="input" required minLength={2} maxLength={100} value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} /></label><label><span className="label">Email address</span><input className="input" type="email" required maxLength={160} value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} /></label><label className="sm:col-span-2"><span className="label">Message</span><textarea className="input min-h-36 resize-y" required minLength={10} maxLength={2000} value={form.message} onChange={(e) => setForm({ ...form, message: e.target.value })} placeholder="Tell us what you need help with…" /></label></div>{error && <p className="mt-3 text-sm text-burgundy" role="alert">{error}</p>}<button disabled={busy} className="btn-primary mt-5"><Send size={15} /> {busy ? 'Saving message…' : 'Send message'}</button></form>
      </section>
    </>
  )
}
