import { create } from 'zustand'
import { persist } from 'zustand/middleware'
import type { CartLine, CharmInstance, NecklaceCartLine, Product, ProductCartLine } from '../lib/types'

interface CartState {
  lines: CartLine[]
  isDrawerOpen: boolean
  addProduct: (product: Product, quantity?: number) => void
  setProductQuantity: (id: string, quantity: number) => void
  removeLine: (id: string) => void
  addNecklace: (instances: CharmInstance[], products: Product[], basePricePkr: number) => void
  clear: () => void
  openDrawer: () => void
  closeDrawer: () => void
}

export const useCartStore = create<CartState>()(
  persist(
    (set) => ({
      lines: [],
      isDrawerOpen: false,

      addProduct: (product, quantity = 1) =>
        set((state) => {
          const id = `product-${product.id}`
          const existing = state.lines.find((line) => line.id === id && line.type === 'product') as ProductCartLine | undefined
          if (existing) {
            return {
              lines: state.lines.map((line) =>
                line.id === id && line.type === 'product' ? { ...line, quantity: Math.min(product.stock_quantity, line.quantity + quantity) } : line,
              ),
              isDrawerOpen: true,
            }
          }
          const line: ProductCartLine = {
            type: 'product',
            id,
            productId: product.id,
            slug: product.slug,
            name: product.name,
            image: product.image_url,
            unitPricePkr: product.price_pkr,
            quantity: Math.min(product.stock_quantity, Math.max(1, quantity)),
          }
          return { lines: [...state.lines, line], isDrawerOpen: true }
        }),

      setProductQuantity: (id, quantity) =>
        set((state) => ({
          lines: quantity <= 0
            ? state.lines.filter((line) => line.id !== id)
            : state.lines.map((line) => (line.id === id && line.type === 'product' ? { ...line, quantity: Math.min(20, quantity) } : line)),
        })),

      removeLine: (id) => set((state) => ({ lines: state.lines.filter((line) => line.id !== id) })),

      addNecklace: (instances, products, basePricePkr) =>
        set((state) => {
          const productMap = new Map(products.map((product) => [product.id, product]))
          const groups = new Map<number, CharmInstance[]>()
          for (const instance of instances) {
            const current = groups.get(instance.productId) || []
            current.push(instance)
            groups.set(instance.productId, current)
          }
          const charms = [...groups.entries()].flatMap(([productId, positions]) => {
            const product = productMap.get(productId)
            if (!product) return []
            return [{
              productId,
              slug: product.slug,
              name: product.name,
              image: product.image_url,
              unitPricePkr: product.price_pkr,
              qty: positions.length,
              positions: positions.map((item) => item.t),
            }]
          })
          const line: NecklaceCartLine = {
            type: 'necklace',
            id: 'custom-necklace',
            name: 'Custom Charm Necklace',
            image: '/logo-mark.svg',
            basePricePkr,
            charms,
            quantity: 1,
            positions: instances.map((item) => ({ ...item })),
          }
          const otherLines = state.lines.filter((item) => item.id !== line.id)
          return { lines: [...otherLines, line], isDrawerOpen: true }
        }),

      clear: () => set({ lines: [], isDrawerOpen: false }),
      openDrawer: () => set({ isDrawerOpen: true }),
      closeDrawer: () => set({ isDrawerOpen: false }),
    }),
    {
      name: 'scarlet-cart-v1',
      version: 1,
      partialize: (state) => ({ lines: state.lines }),
    },
  ),
)

export function lineTotal(line: CartLine): number {
  if (line.type === 'product') return line.unitPricePkr * line.quantity
  return line.basePricePkr + line.charms.reduce((sum, charm) => sum + charm.unitPricePkr * charm.qty, 0)
}

export function cartSubtotal(lines: CartLine[]): number {
  return lines.reduce((sum, line) => sum + lineTotal(line), 0)
}

export function cartBadgeCount(lines: CartLine[]): number {
  return lines.reduce((sum, line) => sum + (line.type === 'product' ? line.quantity : 1), 0)
}
