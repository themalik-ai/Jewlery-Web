import { create } from 'zustand'

type ToastKind = 'success' | 'info' | 'error'
export interface Toast {
  id: string
  message: string
  kind: ToastKind
}

interface UiState {
  toasts: Toast[]
  addToast: (message: string, kind?: ToastKind) => void
  removeToast: (id: string) => void
}

export const useUiStore = create<UiState>((set) => ({
  toasts: [],
  addToast: (message, kind = 'success') => {
    const id = `${Date.now()}-${Math.random().toString(36).slice(2)}`
    set((state) => ({ toasts: [...state.toasts.slice(-3), { id, message, kind }] }))
    window.setTimeout(() => set((state) => ({ toasts: state.toasts.filter((toast) => toast.id !== id) })), 3600)
  },
  removeToast: (id) => set((state) => ({ toasts: state.toasts.filter((toast) => toast.id !== id) })),
}))
