import { create } from 'zustand'
import { api } from '../lib/api'
import { DEFAULT_SETTINGS } from '../config/store'
import type { PublicSettings } from '../lib/types'

interface SettingsState {
  settings: PublicSettings
  loading: boolean
  loaded: boolean
  error: string | null
  load: () => Promise<void>
  refresh: () => Promise<void>
}

export const useSettingsStore = create<SettingsState>((set, get) => ({
  settings: DEFAULT_SETTINGS,
  loading: false,
  loaded: false,
  error: null,
  load: async () => {
    if (get().loaded || get().loading) return
    set({ loading: true, error: null })
    try {
      const settings = await api.settings()
      set({ settings, loaded: true, loading: false })
    } catch (error) {
      set({ loading: false, loaded: true, error: error instanceof Error ? error.message : 'Settings unavailable.' })
    }
  },
  refresh: async () => {
    set({ loading: true, error: null })
    try {
      const settings = await api.settings()
      set({ settings, loaded: true, loading: false })
    } catch (error) {
      set({ loading: false, error: error instanceof Error ? error.message : 'Settings unavailable.' })
    }
  },
}))
