import { create } from 'zustand'
import { persist } from 'zustand/middleware'
import type { CharmInstance } from '../lib/types'
import { clampT, defaultCharmT } from '../lib/necklace'

const clone = (value: CharmInstance[]) => value.map((item) => ({ ...item }))
const same = (a: CharmInstance[], b: CharmInstance[]) => JSON.stringify(a) === JSON.stringify(b)

function uid(): string {
  if (typeof crypto !== 'undefined' && 'randomUUID' in crypto) return crypto.randomUUID()
  return `charm-${Date.now()}-${Math.random().toString(36).slice(2)}`
}

interface EditorState {
  instances: CharmInstance[]
  history: CharmInstance[][]
  future: CharmInstance[][]
  zoom: number
  selectedInstanceId: string | null
  addCharm: (productId: number, t?: number) => string
  setProductQuantity: (productId: number, quantity: number) => void
  moveTransient: (instanceId: string, t: number) => void
  commitMove: (before: CharmInstance[]) => void
  removeInstance: (instanceId: string) => void
  removeProduct: (productId: number) => void
  selectInstance: (instanceId: string | null) => void
  undo: () => void
  redo: () => void
  clear: () => void
  setZoom: (zoom: number) => void
  resetZoom: () => void
  loadDesign: (instances: CharmInstance[]) => void
}

function pushState(state: EditorState, next: CharmInstance[], selected: string | null = state.selectedInstanceId) {
  if (same(state.instances, next)) return {}
  return {
    instances: clone(next),
    history: [...state.history.slice(-49), clone(state.instances)],
    future: [],
    selectedInstanceId: selected,
  }
}

export const useEditorStore = create<EditorState>()(
  persist(
    (set, get) => ({
      instances: [],
      history: [],
      future: [],
      zoom: 1,
      selectedInstanceId: null,

      addCharm: (productId, t) => {
        const state = get()
        const instance: CharmInstance = {
          instanceId: uid(),
          productId,
          t: clampT(t ?? defaultCharmT(state.instances)),
        }
        set(pushState(state, [...state.instances, instance], instance.instanceId))
        return instance.instanceId
      },

      setProductQuantity: (productId, quantity) => {
        const state = get()
        const target = Math.max(0, Math.min(12, Math.round(quantity)))
        const current = state.instances.filter((item) => item.productId === productId)
        if (current.length === target) return
        let next = clone(state.instances)
        let selected = state.selectedInstanceId
        if (target > current.length) {
          for (let i = current.length; i < target; i += 1) {
            const instance: CharmInstance = { instanceId: uid(), productId, t: defaultCharmT(next) }
            next.push(instance)
            selected = instance.instanceId
          }
        } else {
          const removeIds = new Set(current.slice(target).map((item) => item.instanceId))
          next = next.filter((item) => !removeIds.has(item.instanceId))
          if (selected && removeIds.has(selected)) selected = null
        }
        set(pushState(state, next, selected))
      },

      moveTransient: (instanceId, t) => {
        set((state) => ({
          instances: state.instances.map((item) =>
            item.instanceId === instanceId ? { ...item, t: clampT(t) } : item,
          ),
          selectedInstanceId: instanceId,
        }))
      },

      commitMove: (before) => {
        const state = get()
        if (same(before, state.instances)) return
        set({
          history: [...state.history.slice(-49), clone(before)],
          future: [],
        })
      },

      removeInstance: (instanceId) => {
        const state = get()
        const next = state.instances.filter((item) => item.instanceId !== instanceId)
        set(pushState(state, next, state.selectedInstanceId === instanceId ? null : state.selectedInstanceId))
      },

      removeProduct: (productId) => {
        const state = get()
        const removedIds = new Set(state.instances.filter((item) => item.productId === productId).map((item) => item.instanceId))
        const next = state.instances.filter((item) => item.productId !== productId)
        set(pushState(state, next, state.selectedInstanceId && removedIds.has(state.selectedInstanceId) ? null : state.selectedInstanceId))
      },

      selectInstance: (instanceId) => set({ selectedInstanceId: instanceId }),

      undo: () => {
        const state = get()
        const previous = state.history.at(-1)
        if (!previous) return
        set({
          instances: clone(previous),
          history: state.history.slice(0, -1),
          future: [clone(state.instances), ...state.future].slice(0, 50),
          selectedInstanceId: null,
        })
      },

      redo: () => {
        const state = get()
        const next = state.future[0]
        if (!next) return
        set({
          instances: clone(next),
          history: [...state.history, clone(state.instances)].slice(-50),
          future: state.future.slice(1),
          selectedInstanceId: null,
        })
      },

      clear: () => {
        const state = get()
        if (state.instances.length === 0) return
        set(pushState(state, [], null))
      },

      setZoom: (zoom) => set({ zoom: Math.min(1.75, Math.max(0.75, Math.round(zoom * 100) / 100)) }),
      resetZoom: () => set({ zoom: 1 }),

      loadDesign: (instances) => {
        const state = get()
        set(pushState(state, instances.map((item) => ({ ...item, t: clampT(item.t) })), null))
      },
    }),
    {
      name: 'scarlet-necklace-design-v1',
      version: 1,
      partialize: (state) => ({ instances: state.instances, zoom: state.zoom }),
    },
  ),
)
